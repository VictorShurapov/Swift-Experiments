


//name surname height weight age


let momsName = "Natasha"
let momsSurname = "Sushenko"
let momsHeight = 146
let momsWeight = 45
let momsAge = 47

println("My Mom`s name is \(momsName)\nMy Mom`s surname is \(momsSurname)\nMy Mom`s height is \(momsHeight) sm\nMy Mom`s weight is \(momsWeight) kg\nMy Mom`s age is \(momsAge)")


var redColor = "red"



