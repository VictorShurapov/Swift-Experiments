// 1. Создайте расширение для Int с пропертисами isNegative, isPositive, bool
// 2. Добавьте проперти, которое возвращает количество символов в числе
// 3. Добавьте сабскрипт, который возвращает символ числа по индексу
extension Int {
    
    var isPositive: Bool {
        return self > 0
    }
    var isNegative: Bool {
        return self < 0
    }
    
    var bool : Bool {
        return self != 0
    }
    
    var countElements: Int {
        return count(String(self))
        
    }
    
    subscript(var digitIndex: Int) -> Int {
        get {
            var decimalBase = 1
            while digitIndex > 0 {
                decimalBase *= 10
                --digitIndex
            }
            return (self / decimalBase) % 10
        }
    }
}

var a = 5
var b = -5
var c = 0

a.isPositive
a.bool
b.isNegative
b.bool
c.bool

var d = 123
d.countElements

d[0]
d[1]
d[2]


// 4. Расширить String, чтобы принимал сабскрипт вида s[0..<3] и мог также устанавливать значения используя его
func genStringRange(string: String, range: Range<Int>) -> Range<String.Index> {
    let start = advance(string.startIndex, range.startIndex)
    let end = advance(string.startIndex, range.endIndex)
    return Range(start: start, end: end)
}

extension String {
    subscript(range: Range<Int>) -> String {
        get {
            let range = genStringRange(self, range)
            return self[range]
        }
        set {
            let range = genStringRange(self, range)
            self.replaceRange(range, with: newValue)
        }
    }
}

var vitek = "Vityok"
vitek[0..<3]
vitek[4...5]
vitek[4...5] = "ya"
vitek

// 5. Добавить стрингу метод truncate, чтобы отрезал лишние символы и , если таковые были, заменял их на троеточие:
extension String {
    mutating func truncate(length: Int) {
        if count(self) <= length {
            return ()
        }
        let start = advance(self.startIndex, length)
        let range = Range(start: start, end: self.endIndex)
        self.replaceRange(range, with: "...")
    }
}

var punks = "not dead!!"
punks.truncate(10)
punks.truncate(6)
punks