//1. Объявить протокол Food, который будет иметь проперти name (только чтение) и метод taste(), который будет выводить текст со вкусовыми ощущениями

protocol Food {
    var name: String { get }
    func taste()
}
protocol Storable: Food {
    var expired: Bool { get }
    var daysToExpire: Int { get }
}

//2. Все продукты разных типов, которые вы принесли из супермаркета, находятся в сумке (массив) и все, как ни странно, реализуют протокол Food. Вам нужно пройтись по сумке, назвать предмет и откусить кусочек. Можете отсортировать продукты до имени. Используйте для этого отдельную функцию, которая принимает массив продуктов

class Fruits: Storable {
    var name: String
    func taste() {
        print("Wow! \(name) is so sweet!!")
    }
    var expired: Bool = false
    var daysToExpire = 14
    init(name: String) {
        self.name = name
    }
}

class Vegetables: Storable {
    var name: String
    func taste() {
        print("Fresh \(name) tastes great!! I like it!")
    }
    var expired: Bool = false
    var daysToExpire = 17
    init(name: String) {
        self.name = name
    }
}

struct Nuts: Food {
    var name: String
    func taste() {
        print("Delicious \(name)!")
    }
}

var banana = Fruits(name: "Banana")
banana.expired = true

var apple = Fruits(name: "Apple")
apple.daysToExpire = 14
var pear = Fruits(name: "Pear")
pear.daysToExpire = 16
var peach = Fruits(name: "Peach")
peach.expired = true

var tomato = Vegetables(name: "Tomato")
tomato.expired = true
var cucumber = Vegetables(name: "Cucumber")
cucumber.daysToExpire = 2

var walnut = Nuts(name: "Walnut")
var cashew = Nuts(name: "Cashew")
typealias Bag = [Food]
var bag: Bag = [banana, apple, peach, pear, tomato, cucumber, walnut, cashew]

func printSortedBag(array: Bag) {
    
let bagSortedByName = bag.sort({ $0.name < $1.name })
    print("I put this products to my bag")
for i in bagSortedByName {
    print(i.name)
    i.taste()
}
}

printSortedBag(bag)
print("")

//3. Некоторые продукты могут испортиться, если их не положить в холодильник. Создайте новый протокол Storable, он наследуется от протокола Food и содержит еще булевую проперти - expired.
//У некоторых продуктов замените Food на Storable. 
//Теперь пройдитесь по всем продуктам и, если продукт надо хранить в холодильнике, то перенесите его туда, но только если продукт не испорчен уже, иначе просто избавьтесь от него. Используйте функцию для вывода продуктов для вывода содержимого холодильника

//4. Добавьте проперти daysToExpire в протокол Storable. Отсортируйте массив продуктов в холодильнике. Сначала пусть идут те, кто быстрее портятся. Если срок совпадает, то сортируйте по имени.


func freshFilter(bag: Bag) -> Bag {
    var fridge: Bag = []
    for i in bag {
        if let i = i as? Storable where !i.expired {
            fridge.append(i)
        }
    }
    print("Let's see what's in the fridge: ")
    for i in fridge {
        print(i.name)
    }
    return fridge
}

let fridge = freshFilter(bag)


func fridgeFilter(fridge: Bag) -> Bag {
    return fridge.sort({
    let d1 = ($0 as! Storable).daysToExpire
    let d2 = ($1 as! Storable).daysToExpire
        if d1 == d2 {
            return $0.name < $1.name
        }
        return d1 < d2
    })
}

let filteredFridge = fridgeFilter(fridge)
