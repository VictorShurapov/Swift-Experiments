class Human {
    var weight: Int
    var age: Int
    
    init(weight: Int, age: Int) {
        self.weight = weight
        self.age = age
    }
    
    convenience init(age: Int) {
        self.init(weight: 0, age: age)
    }
    
    convenience init(weight: Int) {
        self.init(weight: weight, age: 0)
    }
    
    convenience init() {
        self.init(weight: 0)
    }
    
    func test(){}
    
}


class Student: Human {
    var firstName: String
    var lastName: String
    
    init(firstName: String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
        super.init(weight: 0, age: 0)// обязательно инициализировать свойства суперкласса в подклассе `после инициализации свойств подкласса`
        self.weight = 50
    }
    
    override convenience init(weight: Int, age: Int) {
        self.init(firstName: "")// переопределили десигн инит родителя в конв инит этого класса
        self.weight = weight
        self.age = age
    }
    
    convenience init(firstName: String) {
        self.init(firstName: firstName, lastName: "")
        self.age = 28
    }
}

class Doctor: Student {
    var fieldOfStudy: String
    init(fieldOfStudy: String) {
        self.fieldOfStudy = fieldOfStudy
        super.init(firstName: "Vitya", lastName: "Pro")
    }
    override init(firstName: String, lastName: String) {
        self.fieldOfStudy = "Health"
        super.init(firstName: firstName, lastName: lastName)
    }
    
    convenience init(firstName: String) {
        self.init(fieldOfStudy: "Math")
        self.age = 35
        self.firstName = firstName
    }
    
    /*
    override init(weight: Int, age: Int) {
        fieldOfStudy = ""
        super.init(weight: weight, age: age)
    }
    */
    /*
    convenience init(fieldOfStudy: String) {
        self.init(firstName: "Doctor", lastName: "Aibolit")
        self.fieldOfStudy = fieldOfStudy
    }
    */
}
let d1 = Doctor(firstName: "Piu", lastName: "Piu") // base class designated init
let d2 = Doctor(firstName: "Aibolit") // base class conv init
d2.age
let d3 = Doctor(fieldOfStudy: "Code") // sub class designated

let s1 = Student()
let bb = Student(weight: 22, age: 22)
