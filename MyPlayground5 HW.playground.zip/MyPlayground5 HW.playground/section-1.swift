//1 my birthday - 30.12

let months = ( jan: 31, feb: 28, mar: 31, apr:30, may:31, jun: 30, jul:31, aug: 31, sep: 30, oct: 31, nov: 30, dec: 31)
let secondsInDay = 24 * 60 * 60

let daysToBirthday = months.jan + months.feb + months.mar + months.apr + months.may + months.jun + months.jul + months.aug + months.sep + months.oct + months.nov + months.dec - 1
let secondsToBirthday = daysToBirthday * secondsInDay

//2 
let firstQuarter = (months.jan + months.feb + months.mar) * secondsInDay
let secondQuarter = (months.jan + months.feb + months.mar + months.apr + months.may + months.jun) * secondsInDay
let thirdQuarter = (months.jan + months.feb + months.mar + months.apr + months.may + months.jun + months.jul + months.aug + months.sep) * secondsInDay
let fourthQuarter = (months.jan + months.feb + months.mar + months.apr + months.may + months.jun + months.jul + months.aug + months.sep + months.oct + months.nov + months.dec) * secondsInDay

if secondsToBirthday <= firstQuarter {
    println("My birthday is in the first quarter\n")
} else if secondsToBirthday > firstQuarter && secondsToBirthday <= secondQuarter {
    println("My birthday is in the second quarter\n")
} else if secondsToBirthday > secondQuarter && secondsToBirthday <= thirdQuarter {
    println("My birthday is in the third quarter\n")
} else if secondsToBirthday > thirdQuarter && secondsToBirthday <= fourthQuarter {
    println("My birthday is in the fourth quarter\n")
}
4
//3
var a = 1
var b = 2
var c = 3
var d = 4
var e = 5

let deal = ++a - --b + c++ + d-- - e++
let check1 = (1 + 1) - (2 - 1) + 3 + 4 - 5

a
b
c
d
e

let deal2 = (--a * ++b / ++c) + d-- - e++
let check2 = ((2 - 1) * (1 + 1) / (4 + 1)) + 3 - 6
//4
let cell = (x:1, y:1)

if cell.x % 2 == cell.y % 2 {
    println("black")
} else {
    println("white")
}

