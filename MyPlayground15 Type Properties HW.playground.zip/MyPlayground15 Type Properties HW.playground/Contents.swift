/*1. Создать структуру “Описание файла” содержащую свойства:
- путь к файлу
- имя файла
- максимальный размер файла на диске
- путь к папке, содержащей этот файл
- тип файла (скрытый или нет)
- содержимое файла (можно просто симулировать контент)
Главная задача - это использовать правильные свойства там, где нужно, чтобы не пришлось хранить одни и те же данные в разных местах и т.д. и т.п.
*/
var Data = "Главная задача - это использовать правильные свойства."

enum FileType : String {
    case Hidden = "Hidden"
    case Visible = "Visible"
}


struct File {
    
    var folderPath : String
    
    var name : String
    
    static var maxSize = 100
    
    var filePath : String {
        return folderPath + "/" + name
    }
    
    var fileType : FileType
    
    var content : String {
        didSet {
            if count(content) > File.maxSize {
                content = oldValue
            }
        }
    }
}


var newFile = File(folderPath: "Users/Vitya/Documents", name: "SwiftTut", fileType: .Visible, content: Data)
newFile.filePath
newFile.name
File.maxSize
newFile.folderPath
newFile.fileType.rawValue
newFile.content

println("File: \(newFile.name), FilePath: \(newFile.filePath), FileType: \(newFile.fileType.rawValue), Content: \(newFile.content)")

//2. Создайте энум, который будет представлять некую цветовую гамму. Этот энум должен быть типа Int и как raw значение должен иметь соответствующее 3 байтное представление цвета. Добавьте в этот энум 3 свойства типа: количество цветов в гамме, начальный цвет и конечный цвет.


enum Colors: Int {
    
    case Green = 0x00FF00
    case Yellow = 0xFFFF00
    case Purple = 0xA020F0
    
    static var colorsNumber = 3
    static var firstColor = Colors.Green
    static var lastColor = Colors.Purple
}

Colors.Yellow.rawValue
Colors.colorsNumber
Colors.firstColor.rawValue
Colors.lastColor.rawValue

//3. Создайте класс человек, который будет содержать имя, фамилию, возраст, рост и вес. Добавьте несколько свойств непосредственно этому классу чтобы контролировать:
//-- минимальный и максимальный возраст каждого объекта
//-- минимальную и максимальную длину имени и фамилии
//-- минимально возможный рост и вес-- самое интересное, создайте свойство, которое будет содержать количество созданных объектов этого класса

let Couple = 2

class Human {
    
    static var minAge = 1
    static var maxAge = 100
    
    static var maxNameLength = 10
    static var minNameLength = 2
    
    static var minHeight = 30
    static var minWeight = 10
    
    static var totalHumans = 0
    lazy var love = "Nastya + Vitya = <3"
    
    
    var name : String {
        didSet {
            if count(name) > Human.maxNameLength || count(name) < Human.minNameLength {
                name = oldValue
            }
        }
    }
    
    var surname : String {
        didSet {
            if count(surname) > Human.maxNameLength || count(surname) < Human.minNameLength {
                surname = oldValue
            }
        }
    }
    
    var age : Int {
        didSet {
            if age > Human.maxAge || age < Human.minAge {
                age = oldValue
            }
        }
    }
    
    var height : Int {
        didSet {
            if height < Human.minHeight {
                height = oldValue
            }
        }
    }
    
    var weight : Int {
        didSet {
            if weight < Human.minWeight {
                weight = oldValue
            }
        }
    }
    
    init(name: String, surname: String, age: Int, height: Int, weight: Int) {
        self.name = name
        self.surname = surname
        self.age = age
        self.height = height
        self.weight = weight
        
        Human.totalHumans++
    }
}


var nastya = Human(name: "Nastyupon", surname: "Lybimii", age: 21, height: 180, weight: 88)

var vitya = Human(name: "Vitek", surname: "Sulyapov", age: 24, height: 180, weight: 63)

nastya.name
Human.totalHumans
vitya.surname

func printLove(totalHumans: Int) -> String {
    if totalHumans == Couple {
        println(nastya.love)
    }
    return nastya.love
}

printLove(Human.totalHumans)
nastya
