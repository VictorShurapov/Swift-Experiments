// ~ ~ ~Functions
// ~ ~ Defining and Calling Functions ==========
func sayHello(personName: String) -> String {
    let greeting = "Hello, " + personName + "!"
    return greeting
}

println(sayHello("Anna"))
println(sayHello("Brian"))

func sayHelloAgain(personName: String) -> String {
    return "Hello again, " + personName + "!"
}

println(sayHelloAgain("Anna"))


// ~ ~ Function Parameters and Return Values =========

// Multiple Input Parameters

func halfOPenRangeLength(start: Int, end: Int) -> Int {
    return end - start
}
println(halfOPenRangeLength(1, 10))

//Functions Without Parameters

func sayHelloWorld() -> String {
    return "hello, world"
}
println(sayHelloWorld())

// Functions Without Return Values

func sayGoodbye(personName: String) {
    println("Goodbye, \(personName)!")
}
sayGoodbye("Dave")

func printAndCount(stringToPrint: String) -> Int {
    println(stringToPrint)
    return count(stringToPrint)
}

func printWithoutCounting(stringToPrint: String) {
    printAndCount(stringToPrint)
}

let b = printAndCount("hello, world")

printWithoutCounting("hello, world") // - without return value

// Functions with Multiple Return Values


func minMax(array: [Int]) -> (min: Int, max: Int) {
    var currentMin = array[0]
    var currentMax = array[0]
    for value in array[1..<array.count] {
        if value < currentMin {
            currentMin = value
        } else if value > currentMax {
            currentMax = value
        }
    }
    return (currentMin, currentMax)
}

let bounds = minMax([8, -6, 2, 109, 3, 71])
println("min is \(bounds.min) and max is \(bounds.max)")

// Optional Tuple Return Types

func minMaxOpt(array: [Int]) -> (min: Int, max: Int)? {
    if array.isEmpty { return nil }
    var currentMin = array[0]
    var currentMax = array[0]
    for value in array[1..<array.count] {
        if value < currentMin {
            currentMin = value
        } else if value > currentMax {
            currentMax = value
        }
    }
    return (currentMin, currentMax)
}

// use optional binding to check whether this version of the minMax function returns an actual tuple value or nil:

if let bounds = minMaxOpt([8, -6, 2, 109, 3, 71]) {
    println("min is \(bounds.min) and max is \(bounds.max)")
}

// ~ ~ Function Parameter Names =============

//local parameter names - only available for use within the function's body:
func someFunction(parameterName: Int) {}

//External Parameter Names

func someFunction2(externalParameterName localParameterName: Int) {}

func join(string s1: String, toString s2: String, withJoiner joiner: String) -> String {
    return s1 + joiner + s2
}

join(string: "hello", toString: "world", withJoiner: ", ")

// Shorthand External Parameters Names

func containsCharacter(#string: String, #characterToFind: Character) -> Bool {
    for character in string {
        if character == characterToFind {
            return true
        }
    }
    return false
}

let containsAVee = containsCharacter(string: "aardvark", characterToFind: "v")

// Default Parameter Values

func joinDef(string s1: String, toString s2: String,
    withJoiner joiner: String = " ") -> String {
        return s1 + joiner + s2
}

/*If a string value for joiner is provided that string value is used to join the two strings together, as before:*/

joinDef(string: "hello", toString: "world", withJoiner: "-")

/*if no value of joiner is provided when the function is called, the default value of a single space (" ") is used instead:*/

joinDef(string: "hello", toString: "world")

//External Names for Parameters with Default Values

func joinExtNamesForParWithDefVal(s1: String, s2: String, joiner: String = " ") -> String {
    return s1 + joiner + s2
}

joinExtNamesForParWithDefVal("hello", "world", joiner: "-")

// Variadic Parameters (...)

func alignRight(var string: String, count2: Int, pad: Character) -> String {
    let amountToPad = count2 - count(string)
    if amountToPad < 1 {
        return string
    }
    let padString = String(pad)
    for _ in 1...amountToPad {
        string = padString + string
    }
    return string
}
let originalString = "hello"
let paddedString = alignRight(originalString, 10, "-")

// In-Out Parameters

func swapTwoInts(inout a: Int, inout b: Int) {
    let temporaryA = a
    a = b
    b = temporaryA
}

var someInt = 3
var anotherInt = 107
swapTwoInts(&someInt, &anotherInt)

println("someInt is now \(someInt), and anotherInt is now \(anotherInt)")

// ~ ~ Function Types ==================

func addTwoInts(a: Int, b: Int) -> Int {
    return a + b
} // (Int, Int) -> Int
func multiplyTwoInts(a: Int, b: Int) -> Int {
    return a * b
} // (Int, Int) -> Int

func printHelloWorld() {
    println("hello, world")
} // () -> ()  -- returns Void(equivalent to an empty tuple, "()")

// Using Function Types
var mathFunction: (Int, Int) -> Int = addTwoInts
println("Result: \(mathFunction(2, 3))")
mathFunction = multiplyTwoInts
println("Result: \(mathFunction(2, 3))")

let anotherMathFunction = addTwoInts

// Function Types as Parameter Types

func printMathResult(mathFunction: (Int, Int) -> Int, a: Int, b: Int) {
    println("Result: \(mathFunction(a, b))")
}
printMathResult(addTwoInts, 3, 5)

// “Function Types as Return Types

func stepForward(input: Int) -> Int {
    return input + 1
}
func stepBackward(input: Int) -> Int {
    return input - 1
}

func chooseStepFunction(backwards: Bool) -> (Int) -> Int {
    return backwards ? stepBackward : stepForward
}

var currentValue = 3
let moveNearerToZero = chooseStepFunction(currentValue > 0)

println("Counting to zero:")
while currentValue != 0 {
    println("\(currentValue)... ")
    currentValue = moveNearerToZero(currentValue)
}
println("zero!")

// ~ ~ Nested Functions
func chooseStepFunctionWithNested(backwards: Bool) -> (Int) -> Int {
    func stepForward(input: Int) -> Int {
        return input + 1 }
    func stepBackward(input: Int) -> Int {
        return input - 1 }
    return backwards ? stepBackward : stepForward
    }
var currentValue2 = -4
let moveNearerToZero2 = chooseStepFunctionWithNested(currentValue2 > 0)

while currentValue2 != 0 {
    println("\(currentValue2)... ")
    currentValue2 = moveNearerToZero2(currentValue2)
}
println("zero!")
