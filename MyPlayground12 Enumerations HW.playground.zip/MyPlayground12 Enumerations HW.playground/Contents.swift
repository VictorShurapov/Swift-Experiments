//1. Создать энум с шахматными фигурами (король, ферзь и т.д.). Каждая фигура должна иметь цвет белый либо черный (надеюсь намек понят), а так же букву и цифру для позиции. Создайте пару фигур с расположением на доске, так, чтобы черному королю был мат :) Поместите эти фигуры в массив фигур
enum Figures {
    enum Name : String {
        case Pawn = "Pawn"
        case Knight = "Knight"
        case Rook = "Rook"
        case Bishop = "Bishop"
        case Queen = "Queen"
        case King = "King"
    }
    enum Color : String {
        case White = "White", Black = "Black"
    }
    typealias Pos = (x: Character, y: Int)
    case Pawn(Name, Color, Pos)
    case Knight(Name, Color, Pos)
    case Rook(Name, Color, Pos)
    case Bishop(Name, Color, Pos)
    case Queen(Name, Color, Pos)
    case King(Name, Color, Pos)
}

var blackKing = Figures.King(.King, .Black, (x: "e", y: 8))
var whiteQueen = Figures.Queen(.Queen, .White, (x: "f", y: 7))
var whiteBishop = Figures.Bishop(.Bishop, .White, (x: "c", y: 4))
var blackKnight = Figures.Knight(.Knight, .Black, (x: "f", y: 6))
var blackKnight2 = Figures.Knight(.Knight, .Black, (x: "c", y: 6))
var whitePawn = Figures.Pawn(.Pawn, .White, (x: "e", y: 4))
var blackPawn = Figures.Pawn(.Pawn, .Black, (x: "e", y: 5))



var foolsMate = [blackKing, whiteQueen, whiteBishop, blackKnight, blackKnight2, whitePawn, blackPawn]

//2. Сделайте так, чтобы энумовские значения имели rawValue типа String. Каждому типу фигуры установите соответствующее английское название. Создайте функцию, которая выводит в консоль (текстово, без юникода) название фигуры, цвет и расположение. Используя эту функцию распечатайте все фигуры в массиве.
func printInfo(piece: Figures) {
    switch piece {
    case let .Pawn(name, color, (x, y)):
        println("\(name.rawValue), \(color.rawValue), (\(x) \(y))")
    case let .Knight(name, color, (x, y)):
        println("\(name.rawValue), \(color.rawValue), (\(x) \(y))")
    case let .Bishop(name, color, (x, y)):
        println("\(name.rawValue), \(color.rawValue), (\(x) \(y))")
    case let .Queen(name, color, (x, y)):
        println("\(name.rawValue), \(color.rawValue), (\(x) \(y))")
    case let .King(name, color, (x, y)):
        println("\(name.rawValue), \(color.rawValue), (\(x) \(y)) checkmate")
    default:
        break
    }
}
func iteration(array: [Figures]) {
    for i in array {
        printInfo(i)
    }
}
iteration(foolsMate)

//3. Используя красивые юникодовые представления шахматных фигур, выведите в консоли вашу доску. Если клетка не содержит фигуры, то используйте белую или черную клетку. Это должна быть отдельная функция, которая распечатывает доску с фигурами (принимает массив фигур и ничего не возвращает)


typealias FigureInfo = (name: String, color: Figures.Color, pos: Figures.Pos)

func figureInfo(figure: Figures) -> FigureInfo {
    typealias Names = Figures.Name
    
    switch figure {
    case let .Pawn(_, col, pos): return(Names.Pawn.rawValue, col, pos)
    case let .Knight(_, col, pos): return(Names.Knight.rawValue, col, pos)
    case let .Rook(_, col, pos): return(Names.Rook.rawValue, col, pos)
    case let .Bishop(_, col, pos): return(Names.Bishop.rawValue, col, pos)
    case let .Queen(_, col, pos): return(Names.Queen.rawValue, col, pos)
    case let .King(_, col, pos): return(Names.King.rawValue, col, pos)
    }
}

func draw(figures: [Figures]) {
   func figureView(figure: Figures) -> Character? {
        typealias Color = Figures.Color
        switch figure {
            
        case let .Pawn(_, col, _) where col == .White: return "♙"
        case let .Pawn(_, col, _) where col == .Black: return "♟"
            
        case let .Knight(_, col, _) where col == .White: return "♘"
        case let .Knight(_, col, _) where col == .Black: return "♞"
            
        case let .Rook(_, col, _) where col == .White: return "♖"
        case let .Rook(_, col, _) where col == .Black: return "♜"
            
        case let .Bishop(_, col, _) where col == .White: return "♗"
        case let .Bishop(_, col, _) where col == .Black: return "♝"
            
        case let .Queen(_, col, _) where col == .White: return "♕"
        case let .Queen(_, col, _) where col == .Black: return "♛"
            
        case let .King(_, col, _) where col == .White: return "♔"
        case let .King(_, col, _) where col == .Black: return "♚"
        default : return nil
        }
    }
    func figure(pos: Figures.Pos) -> Character? {
        for val in figures {
            let info = figureInfo(val)
            if pos.x == info.pos.x && pos.y == info.pos.y {
                return figureView(val)
            }
        }
        return nil
    }
let hor = "abcdefgh"
let ver = 1...8

    for i in ver {
        print("\(9 - i)");
        for (j, x) in enumerate(hor) {
            if let figure = figure((x, 9 - i)) {
                print(figure)
                continue
            }
            print(i % 2 == j % 2 ? "⬛" : "⬜")
        }
        println()
    }
    println(" a  b c d  e f g h")
}

draw(foolsMate)
