// ~ ~ Control Flow - Поток(порядок) выполнения(управления)

// ~ For Loops
// For-in

for index in 1...5 {
    println("\(index) times 5 is \(index * 5)")
}

// with underscore
let base = 3
let power = 10
var answer = 1
for _ in 1...power {
    answer *= base
}
println("\(base) to the power of \(power) is \(answer)")

// for-in with an array to iterate over its items

let names = ["Anna", "Alex", "Brian", "Jack"]
for name in names {
    println("Hello, \(name)!")
}

// for-in with the dictionary

let numberOfLegs = ["spider": 8, "ant": 6, "cat": 4]
for (animalName, legCount) in numberOfLegs {
    println("\(animalName)s have \(legCount) legs")
}

// for-in with Character values in a string

for character in "Hello" {
    println(character)
}

// ~ For :
/* for initialization; condition; increment {
       statements
} */

for var index = 0; index < 3; ++index {
    println("index is \(index)")
}

//to retrieve the final value of index after the loop ends - declare index before the loop's scope begins

var index: Int
for index = 0; index < 3; ++index {
    println("index is \(index)")
}
println("The loop statements were executed \(index) times")

// ~ While Loops

/* While

while condition {
    statements
} */

let finalSquare = 25
var board = [Int](count: finalSquare + 1, repeatedValue: 0)
board[03] = +08; board[06] = +11; board[09] = +09; board[10] = +02
board[14] = -10; board[19] = -11; board[22] = -02; board[24] = -08

var square = 0
var diceRoll = 0
/* while square < finalSquare {
    if ++diceRoll == 7 { diceRoll = 1 }
    square += diceRoll
    if square < board.count {
        square += board[square]
    }
}
println("Game over!") */

/* Do-While

do {
    statements
  } while condition */

do {
    square += board[square]
    if ++diceRoll == 7 { diceRoll = 1 }
    square += diceRoll
} while square < finalSquare
println("Game over!")

// ~ Conditional Statements: If

var temperatureInFahrenheit = 30
if temperatureInFahrenheit <= 32 {
    println("It's very cold. Consider wearing a scarf.")
}

// with else clause
temperatureInFahrenheit = 40
if temperatureInFahrenheit <= 32 {
    println("It's very cold. Consider wearing a scarf.")
} else {
    println("It's not that cold. Wear a t-shirt.")
}

//chain of multiple if statements
temperatureInFahrenheit = 90
if temperatureInFahrenheit <= 32 {
    println("It's very cold. Consider wearing a scarf.")
} else if temperatureInFahrenheit >= 86 {
    println("It's really warm. Don't forget to wear sunscreen.")
} else {
    println("It's not that cold. Wear a t-shirt.")
}