//DRY

func calculateMoney(wallet: [Int], type: Int?) -> (total: Int, count: Int) {
    
    var sum = 0
    var count = 0
    
    for value in wallet {
        
        if (type == nil) ||
            (value == type!) {
            sum += value
            count++
            
        }
    }
    return (sum, count)
}

func calculateMoney(inSequence range: Int...) -> Int{
    
    var sum = 0
    for value in range {
        sum += value
    }
     return sum
}

let wallet = [100, 5, 1, 5, 5 ,20, 50 ,100, 1, 1]

var (money, count) = calculateMoney(wallet, 5)
money
count

calculateMoney(wallet, 100).count
calculateMoney(wallet, 100).total

calculateMoney(inSequence: 5, 4, 5, 6, 1, 3, 5, 6, 7)


func sayHi() -> () {
    println("hi")
}

sayHi()

let hi = sayHi

hi()

func sayPhrase(phrase: String) -> Int? {
    println(phrase)
    return 2
}
sayPhrase("aaa")
let phrase : (String) -> (Int?) = sayPhrase
phrase("bbb")

func doSomething(whatToDo: () -> ()) {
    whatToDo()
}

func whatToDo() -> () -> () {
    func printSomething() {
        println("hello, world")
    }
    return printSomething
}

doSomething(sayHi)

let iShouldDoThis = whatToDo()()
iShouldDoThis


