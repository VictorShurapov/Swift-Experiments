// ~ ~ Automatic Reference Counting

// ~ ARC in Action


class Person1 {
    
    let name: String
    
    init(name: String) {
        
        self.name = name
        println("\(name) is being initialized")
        
    }
    deinit {
        println("\(name) is being deinitialized")
    }
}


var reference1: Person1?
var reference2: Person1?
var reference3: Person1?

reference1 = Person1(name: "John Appleseed")

reference2 = reference1
reference3 = reference1

reference1 = nil
reference2 = nil

reference3 = nil

println()
// ~ Strong Reference Cycles Between Class Instances =====

class Person {
    
    let name: String
    init(name: String) { self.name = name }
    
    var apartment: Apartment?
    
    deinit { println("\(name) is being deinitialized") }
}

class Apartment {
    let number: Int
    init(number: Int) { self.number = number }
    var tenant: Person?
    deinit { println("Apartment #\(number) is being deinitialized") }
}

var john: Person?
var number73: Apartment?

john = Person(name: "John Appleseed")
number73 = Apartment(number: 73)


john!.apartment = number73
number73!.tenant = john

john = nil
number73 = nil

// ~ Resolving Strong Reference Cycles Between Class Instances
// ~ Weak References
class PersonWeak {
    let name: String
    init(name: String) { self.name = name }
    var apartment: ApartmentWeak?
    deinit { println("\(name) is being deinitialized") }
}

class ApartmentWeak {
    let number: Int
    init(number: Int) { self.number = number }
    weak var tenant: PersonWeak?
    deinit { println("Apartment #\(number) is being deinitialized") }
}

var johnW: PersonWeak?
var number73W: ApartmentWeak?

johnW = PersonWeak(name: "John Appleseed")
number73W = ApartmentWeak(number: 73)


johnW!.apartment = number73W
number73W!.tenant = johnW

johnW = nil
number73W = nil
println()

// ~ Unowned References

class Customer {
    let name: String
    var card: CreditCard?
    init(name: String) {
        self.name = name
    }
    deinit { println("\(name) is being deinitialized") }
}

class CreditCard {
    let number: UInt64
    unowned let customer: Customer
    init(number: UInt64, customer: Customer) {
        self.number = number
        self.customer = customer
    }
    deinit { println("Card #\(number) is being deinitialized") }
}

var johnny: Customer?
johnny = Customer(name: "Johnny AppleSID")
johnny!.card = CreditCard(number: 1234_5678_9012_3456, customer: johnny!)
johnny = nil
println()

// ~ Unowned References and Implicitly Unwrapped Optional Properties
/*
class Country {
    let name: String
    let capitalCity: City!
    init(name: String, capitalName: String) {
        self.name = name
        self.capitalCity = City(name: capitalName, country: self)
    }
}

class City {
    let name: String
    unowned let country: Country
    init(name: String, country: Country) {
        self.name = name
        self.country = country
    }
}

var country = Country(name: "Canada", capitalName: "Ottawa")
println("\(country.name)'s capital city is called \(country.capitalCity.name)")
*/

// ~ Strong Reference Cycles for Closures =====

class HTMLElement1 {
    let name: String
    let text: String?
    
    lazy var asHTML: () -> String = {
        if let text = self.text {
            return "<\(self.name)>\(text)</\(self.name)>"
        } else {
            return "<\(self.name) />"
        }
    }
    init(name: String, text: String? = nil) {
        self.name = name
        self.text = text
    }
    deinit {
        println("\(name) is being deinitialized")
    }
}

var paragraph1: HTMLElement1? = HTMLElement1(name: "p", text: "hello, world")
println(paragraph1!.asHTML())

paragraph1 = nil

// ~ Resolving Strong Reference Cycles for Closures

// Defining a Capture List

/*
lazy var someClosure: (Int, String) -> String = {
    [unowned self, weak delegate = self.delegate!] (index: Int, stringToProcess: String) -> String in
    //'closure body goes here'
}
*/


//without parameter list and return type
/*
lazy var someClosure: () -> String = {
    [unowned self, weak delegate = self.delegate!] in
    // 'closure body goes here'
}
*/

// Weak and Unowned References

// with [unowned self]
class HTMLElement {
    let name: String
    let text: String?
    
    lazy var asHTML: () -> String = {
        [unowned self] in
        if let text = self.text {
            return "<\(self.name)>\(text)</\(self.name)>"
        } else {
            return "<\(self.name) />"
        }
    }
    init(name: String, text: String? = nil) {
        self.name = name
        self.text = text
    }
    deinit {
        println("\(name) is being deinitialized")
    }
}

var paragraph: HTMLElement? = HTMLElement(name: "p", text: "hello, world")
println(paragraph!.asHTML())

paragraph = nil
