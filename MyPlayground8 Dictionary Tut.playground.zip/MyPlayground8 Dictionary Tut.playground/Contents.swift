// ~ Dictionary syntax
//Dictionary<Key, Value> - full
//[Key: Value] - short

// ~ Creating an Empty Dictionary

var namesOfIntegers = [Int: String]()
namesOfIntegers[16] = "sixteen"
namesOfIntegers = [:]


// ~ Dictionary Literals

var airports1: [String: String] = ["YYZ": "Toronto Pearson", "DUB": "Dublin"]
var airports = ["YYZ": "Toronto Pearson", "DUB": "Dublin"]


// ~ Accessing and Modifying a Dictionary
// count

println("The airports dictionary contains \(airports.count) items.")

// .isEmpty
if airports.isEmpty {
    println("The airports dictionary is empty.")
} else {
    println("The airports dictionary is not empty")
}

// add with subscript syntax (use a new key as  the subscript index and assign a new value)

airports["LHR"] = "London"
airports

// change with subscript sintax

airports["LHR"] = "London Heatrow"


// updateValue(_:forKey:) - set or update the value for a particular key - returns the old value or nil

if let oldValue = airports.updateValue("Dublin Airport", forKey: "DUB") {
    println("The old value for Dub was \(oldValue).")
}

// Retrieve a value from the dictionary for a particular key with the subscript syntax

if let airportName = airports["DUB"] {
    println("The name of the airport is \(airportName).")
} else {
    println("That airport is not in the airports dictionary.")
}
airports["DUB"]

//Remove a key-value pair with nil

airports["APL"] = "Apple International"
airports["APL"] = nil

//Remove a key-value pair with removeValueForKey(_:) - returs the removed value or nil
if let removedValue = airports.removeValueForKey("DUB") {
    println("The removed airport's name is \(removedValue)")
} else {
    println("The airports dictionary does not contain a value for DUB.")
}

// ~ Iterating Over a Dictionary

for (airportCode, airportName) in airports {
    println("\(airportCode): \(airportName)")
}

// for-in with keys and values
for airportCode in airports.keys {
    println("Airport code: \(airportCode)")
}

for airportName in airports.values {
    println("Airport name: \(airportName)")
}

// Array instance
let airportCodes = [String](airports.keys)
airportCodes

let airportNames = [String](airports.values)
