import Foundation
struct Student {
    
    var firstName : String {
        
        willSet(newFirstName) {
            println("will set " + newFirstName + " instead of " + firstName)
        }
        didSet(oldFirstName) {
            println("did set " + firstName + " instead of " + oldFirstName)
            firstName = firstName.capitalizedString
        }
    }
    var lastName : String {
        didSet {
            lastName = lastName.capitalizedString
        }
    }
    var fullName : String {
        get {
            return firstName + " " + lastName
        }
        set {
            println("fullName wants to be set to " + newValue)
            let words = newValue.componentsSeparatedByString(" ")
            
            if words.count > 0 {
                firstName = words[0]
            }
            if words.count > 1 {
                lastName = words[1]
            }
            
        }
    }
    
}


var student = Student(firstName: "Alex", lastName: "Skutarenko")

student.firstName
student.lastName
student.fullName

student.firstName = "Bob"

student.firstName = "sam"
student.lastName
student.fullName

student.fullName = "Vitya Shurapov"


student.firstName
student.lastName
student.fullName

//1

struct StudentDob {
    var day : Int
    var month : Int
    var year : Int
    var currentYear = 2015
    
    var age : Int {
        get {
            return currentYear - year
        }
    }
    var studyingYears : Int {
        return age - 6 < 0 ? 0 : age - 6
    }
    
}

var stDob = StudentDob(day: 30, month: 12, year: 1990, currentYear: 2015)
stDob.age
stDob.studyingYears

var description : String {
    return student.fullName + " \(stDob.age)"
}

println(description)

//2

struct Interval {
    
    struct Point {
        
        var x : Double
        var y : Double
        
    }
    
    var pointA : Point
    var pointB : Point
    
    var midPoint : Point {
        
        get {
            let midPointX = (pointA.x + pointB.x) / 2
            let midPointY = (pointA.y + pointB.y) / 2
            return Point(x: midPointX, y: midPointY)
        }
        set {
            let difX = newValue.x - midPoint.x
            let difY = newValue.y - midPoint.y
            
            pointA.x += difX
            pointB.x += difX
            
            pointA.y += difY
            pointB.y += difY
        }
    }
    
    var length : Double {
        get {
            return sqrt(pow((pointB.x - pointA.x), 2) + pow((pointB.y - pointA.y), 2))
        }
        set {
            pointB = Point(x: pointA.x + (pointB.x - pointA.x) * newValue / length, y: pointA.y + (pointB.y - pointA.y) * newValue / length)
        }
    }
}


var interval = Interval(pointA: Interval.Point(x: 1, y: 4), pointB: Interval.Point(x: 8, y: 8))

println("\nInterval AB: PointA(\(interval.pointA.x), \(interval.pointA.y)), PointB(\(interval.pointB.x), \(interval.pointB.y))")

interval
interval.midPoint
interval.length

println("\nThe middle point is PointC(\(interval.midPoint.x),\(interval.midPoint.y))")
println("Length is \(interval.length)")


interval.midPoint = Interval.Point(x: 10, y: 15)
interval

println("\nAfter the changing of the coordinates the middle point is PointD(\(interval.midPoint.x),\(interval.midPoint.y))")

interval.length = 15
interval.pointB

println("\nAfter I set the length to 15 PointB is at (\(interval.pointB.x), \(interval.pointB.y))")
