//cmd + ] - tab paragraph

//break - continue, label "mainLoop"
mainLoop: for _ in 0...100 {

    for i in 0..<20 {
        if (i < 15) {
            //continue
        }
        if i == 10 {
            break mainLoop
        }
        println(i)
    }
}


var age = 67
var name = "Vitya"

switch age {
case 0...16: println("school");fallthrough
    case 17...21:
        println("student")
    case 22...50: break
    case 52, 57, 60:
        println("nice")
    
default: break
}
//default- other variant
//fallthrough -show next string without evaluating
switch name {
    case "Vitya" where age < 50:
        println("Hi, buddy!")
    case "Vitya" where age >= 50:
        println("I don't know you")
default:
    break
}

let tuple = (name, age)

switch tuple {
    case ("Vitya", 60): println("Hi, Vitya 60")
    case ("Vitya", 59): println("Hi, Vitya 59")
case (_, let number) where number >= 54 && number <= 70:
    println("Hi, old man")
    case ("Vitya", _): println("Hi, Vitya")
default: break
}

/*optional binding
var optionl : Int? = 5
if let optional = optional {
    println("\(optional) != nil")
}*/

let point = (5,-6)

switch point {
    case let (x,y) where x == y:
        println("x == y")
    case let (x,y) where x == -y:
        println("x == - y")
    case let(_,y) where y < 0:
        println("y < 0")
    
    default: break
}

let array : [Printable] = [5, 5.4, Float(5.4)]

switch array[2] {
    case let a as Int: println("Int")
    case _ as Float: println("Float")
    case _ as Double: println("Double")

default: break
}
