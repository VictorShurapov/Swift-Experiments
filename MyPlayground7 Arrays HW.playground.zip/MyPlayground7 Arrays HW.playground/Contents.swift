//1
let daysArray = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]
for days in daysArray {
    print("\(days),")
}

println("\n")
let monthsArray = ["jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec"]

for i in 0..<monthsArray.count {
    println("In \(monthsArray[i]) \(daysArray[i]) days")
}

println("\n")
var yearTuple : [(month : String, day : Int)] = []
for i in 0..<daysArray.count {
    yearTuple.append(month : monthsArray[i], day : daysArray[i])
}
for tuple in yearTuple {
    println("In \(tuple.0) \(tuple.1) days")
}

println("\n")
for var i = daysArray.count - 1; i >= 0; i-- {
    println("In \(monthsArray[i]) \(daysArray[i]) days")
}

let day = 6
let month = 4
var sumOfDays = 0

println("\n")
for mCount in 1...monthsArray.count {
    if month > mCount {
        sumOfDays += daysArray[mCount]
    }
}
sumOfDays += day
println("It`s \(sumOfDays) days to \(monthsArray[month - 1]) \(day)")

// second variant of Days to birthday task
println("\n")
let dob = (month:7, day:6)
var days = 0
for i in 0..<(dob.month - 1) {
    days += daysArray[i]
}
days += dob.day
println("It`s \(days) days to \(monthsArray[month - 1]) \(day)")

//2
let optArray : [Int?] = [1, 5, nil, 6, nil]
var sum = 0
for value in optArray {
    if let value = value {
        sum += value
    }
}
println("Optional sum is \(sum)")

sum = 0
for value in optArray {
    if value != nil {
        sum += value!
    }
}
println("Forced Unwrapping sum is \(sum)")

sum = 0
for value in optArray {
    sum += value ?? 0
}
println("?? sum is \(sum)")

//3
let abc = "abcdefghijklmnopqrstuvwxyz"
var abcArray = [String]()

/*for char in abc {
abcArray.append(String(char))
}
println(abcArray)
*/

for char in abc {
    abcArray.insert(String(char), atIndex: 0)
}
println(abcArray)
