//5. Не все, что мы кладем в холодильник, является едой. Поэтому сделайте так, чтобы Storable не наследовался от Food. Мы по прежнему приносим еду домой, но некоторые продукты реализуют теперь 2 протокола. Холодильник принимает только те продукты, которые еще и Storable. функция сортировки должна по прежнему работать.

protocol Food {
    var name: String { get }
    func taste()
}
protocol Storable {
    var expired: Bool { get }
    var daysToExpire: Int { get }
}
typealias StorableFood = protocol <Food, Storable>

struct Medicines: Storable {
    var name: String
    var expired = false
    var daysToExpire = 365
}

class Fruits: Food, Storable {
    var name: String
    func taste() {
        print("Wow! \(name) is so sweet!!")
    }
    var expired: Bool = false
    var daysToExpire = 14
    init(name: String) {
        self.name = name
    }
}

class Vegetables: Food, Storable {
    var name: String
    func taste() {
        print("Fresh \(name) tastes great!! I like it!")
    }
    var expired: Bool = false
    var daysToExpire = 17
    init(name: String) {
        self.name = name
    }
}

struct Nuts: Food {
    var name: String
    func taste() {
        print("Delicious \(name)!")
    }
}

var pills = Medicines(name: "Vitamins", expired: false, daysToExpire: 365)
var banana = Fruits(name: "Banana")
banana.expired = true

var apple = Fruits(name: "Apple")
apple.daysToExpire = 14
var pear = Fruits(name: "Pear")
pear.daysToExpire = 16
var peach = Fruits(name: "Peach")
peach.expired = true

var tomato = Vegetables(name: "Tomato")
tomato.expired = true
var cucumber = Vegetables(name: "Cucumber")
cucumber.daysToExpire = 2

var walnut = Nuts(name: "Walnut")
var cashew = Nuts(name: "Cashew")

var bag: [Any] = [banana, apple, peach, pear, tomato, cucumber, walnut, cashew, pills]



func filterBag(bag: [Any]) -> [Any] {
    var fridge: [Any] = []
    for i in bag {
        if let i = i as? Storable where !i.expired {
            fridge.append(i)
        }
    }
    print("Let's see what's in the fridge: ")
    for i in fridge {
        if let i = i as? Food {
            print(i.name)
        } else if let i = i as? Medicines {
            print(i.name)
        }
    }
    return fridge
}

let fridge = filterBag(bag)

func fridgeFilter(fridge: [Any]) -> Any {
    return fridge.sort({
        let d1 = ($0 as! Storable).daysToExpire
        let d2 = ($1 as! Storable).daysToExpire
        return d1 < d2
    })
}

let filteredFridge = fridgeFilter(fridge)