


var apples : Int? = 5
//apples = nil

//forced unwrapping

if apples == nil {
    println("nil apples")
} else {
    //println(apples)
    apples! = apples! + 2
}


//optional binding

if var number = apples {
    number = number + 2
} else {
    println("nil apples")
}


let age = "60"
age.toInt()

// forced unwrapping

if age.toInt() != nil {
    let ageNumber = age.toInt()!
}


// opt binding
if let ageNumber = age.toInt() {
    ageNumber
}


//Int
//Int?
//Int!

var apples2 : Int! = nil

apples2 = 2

assert(apples2 != nil, "oh, no!!!")

apples2 = apples2 + 5
