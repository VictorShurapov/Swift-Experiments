// Set Type Syntax ->  Set<String>()

//Creating and Initializing a Set
var letters = Set<Character>()
println("letters is of type Set<Character> with \(letters.count) items.")
letters.insert("a")
letters = []

//Sets with Array Literals
var favoriteGenres1: Set<String> = ["Rock", "Classical", "Hip hop"]
var favoriteGenres: Set = ["Rock", "Classical", "Hip hop"]

//Accessing and Modifying a Set
//- count
println("I have \(favoriteGenres.count) favorite music genres.")

//- isEmpty
if favoriteGenres.isEmpty {
    println("As far as music goes, I'm not picky.")
} else {
    println("I have particular music preferences.")
}

//- insert(_:)
favoriteGenres.insert("Jazz")

//- remove(_:)
if let removedGenre =
    favoriteGenres.remove("Rock") {
        println("\(removedGenre)? I'm over it.")
} else {
    println("I never much cared for that")
}
//favoriteGenres.removeAll()

//- contains(_:)
if favoriteGenres.contains("Funk") {
    println("I get up on the good foot.")
} else {
    println("It's too funky in here.")
}

//Iterating Over a Set
for genre in favoriteGenres {
    println("\(genre)")
}
//- sorted
for genre in sorted(favoriteGenres) {
    println("\(genre)")
}

var sets: Set = [2, 5, 5, 6, 8, 12, 55, 34]

for char in sorted(sets) {
    println("\(char)")
}

//Performing Set Operations
//Constructing Sets: union, subtract(вычитание), intersect(пересечение), exclusiveor(исключение из обоих)
let oddDigits: Set = [1, 3, 5, 7, 9]
let evenDigits: Set = [0, 2, 4, 6, 8]
let singleDigitPrimeNumbers: Set = [2, 3, 5, 7]
sorted(oddDigits.union(evenDigits))
sorted(oddDigits.intersect(evenDigits))
sorted(oddDigits.subtract(singleDigitPrimeNumbers))
sorted(oddDigits.exclusiveOr(singleDigitPrimeNumbers))

//Comparing Sets: "is equal"(==), isSubsetOf(_:), isSupersetOf(_:), isStrictSubsetOf(_:), isSuperSubsetOf(_:), isDisjointWith(_:)

let houseAnimals: Set = ["🐶", "🐱"]
let farmAnimals: Set = ["🐮", "🐔", "🐑", "🐶", "🐱"]
let cityAnimals: Set = ["🐦", "🐭"]
houseAnimals.isSubsetOf(farmAnimals)
farmAnimals.isSupersetOf(houseAnimals)
farmAnimals.isDisjointWith(cityAnimals)

let s1: Set = [1, 2, 3, 4, 5]
let s2: Set = [2, 3]
let s3: Set = [1, 2, 3, 4, 5]
let s4: Set = [15, 16]
s1==s3
s2.isSubsetOf(s1)
s1.isSupersetOf(s2)
s2.isStrictSubsetOf(s1)
s4.isDisjointWith(s1)
s1.isSupersetOf(s2)
