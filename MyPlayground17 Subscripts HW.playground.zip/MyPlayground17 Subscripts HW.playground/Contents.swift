//1 Chessboard

let char = ["a" : 1, "b" : 2, "c" : 3, "d" : 4, "e" : 5, "f" : 6, "g" : 7, "h" : 8]

enum CellType : String {
    case White = "White"
    case Black = "Black"
    case Nil = "Out Of Board"
}

struct ChessBoard {
    var row = 1
    var column = "a"
    
    subscript(row: Int, column: String) -> CellType.RawValue {
        var result : CellType
        let numColumn = char[column] ?? 0
        
        if 1...8 ~= row && 1...8 ~= numColumn {
            result = ((numColumn + row) % 2) == 0 ? .Black : .White
        } else {
            result = .Nil
        }
        return result.rawValue
    }
}

var cell = ChessBoard()

cell[8, "a"]
cell[9, "b"]
cell[1, "a"]

//2 OXO

enum TypeField : String {
    case Free = "⬜"
    case X = "❌"
    case O = "⭕"
}

class Field {
    
    var fields = [Int : TypeField]()
    
    init() {
        for i in 1...9 {
            fields[i] = TypeField.Free
        }
    }
    
    subscript(row: Int, col: Int) -> TypeField? {
        get {
            if (1...3 ~= row) && (1...3 ~= col) {
                return(fields[(row-1) * 3 + col])!
            } else {
                return nil
            }
        }
        set {
            if (1...3 ~= row) && (1...3 ~= col) {
                if fields[(row-1) * 3 + col] == TypeField.Free {
                    fields[(row-1) * 3 + col] = newValue
                }
            }
        }
    }
    
    func show() {
        for i in 1...9 {
            print(fields[i]!.rawValue)
            if i % 3 == 0 {
                println()
            }
        }
    }
    
    func clean() -> [Int : TypeField] {
        for i in 1...9 {
            fields[i] = TypeField.Free
        }
        return fields
    }
    
}

var myField = Field()
myField.show()
println()

myField[2, 2] = TypeField.X
myField[3, 1] = TypeField.O

myField[2, 1] = TypeField.X
myField[2, 3] = TypeField.O

myField[3, 3] = TypeField.X
myField[1, 2] = TypeField.O

myField[1, 1] = TypeField.X

myField.show()

myField.clean() // - clean the fields
println()

myField.show() // - check free space