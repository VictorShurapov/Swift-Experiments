extension Int8 {
    //extension UInt8 {
    func binary() -> String {
        var result = ""
        for i in 0..<8 {
            let mask = 1 << i
            let set = Int(self) & mask != 0
            result = (set ? "1" : "0") + result
        }
        return result
    }
}
Int8.min
var c: Int8
c = -0b10000000

/*              // === Int8
a.binary()

a = 0b01111111
a.binary()
a = a &+ 1
a.binary()
a = a &+ 1
a.binary()

a = 0
a = a - 1
a.binary()
a = a - 1
a.binary()

a = 0b00100001
a = a &* 4
a.binary()      // === Int8
*/


/*
0b11111111
0xff
255
*/

/*                === UInt8
a = 0b00111001
a.binary()
(5 as UInt8).binary()

a = a + 0b00000101
a.binary()
(4 as UInt8).binary()
a = a - 0b00000100
a.binary()

//a = a * 2
//a = a << 2
a = a * 4
a = a &* 2
a.binary()

a = 0b11111111
a = a &+ 1

a = 0b00000000
a = a &- 1
a.binary()         ===
*/

/*
var a: UInt8 = 0b00110011
var b: UInt8 = 0b11100001

a.binary()
b.binary()
(a | b).binary()   // bitwise OR Operator(|): The operator returns a new number whose bits are set to 1 if the bits are equal to 1 in either input number // один из -> 1

a.binary()
b.binary()
(a & b).binary()   // bitwise AND Operator(&): -*- if the bits were equal to 1 in both input numbers // оба -> 1



a.binary()
b.binary()
(a ^ b).binary()   // bitwise XOR Operator(^): The operator returns a new number whose bits are set to 1 where the input bits are different and are set to 0 where the input bits are the same // разные ->1 / одинаковые -> 0

a.binary()
(~a).binary()    // Bitwise NOT Operator(~) inverts all bits in a number

b = 0b00010000   // check to see if the bit(s) is set with(&)
a.binary()
b.binary()
(a & b).binary()

b = 0b00000100   // setting bit to 1 with (|)
a.binary()
b.binary()
(a | b).binary()

b = 0b00000010
a.binary()
b.binary()
(a ^ b).binary() // inverting bit(s) with (^)

b = 0b00010000
a.binary()
b.binary()
(~b).binary()
(a & ~b).binary() // resetting bit(s) with (& ~)

enum CheckList : UInt8 {
case Bread =    0b00000001
case Chicken =  0b00000010
case Apples =   0b00000100
case Pears =    0b00001000
}

let checkList : UInt8 = 0b00001101
let bread = checkList & CheckList.Bread.rawValue
bread.binary()

let chicken = checkList & CheckList.Chicken.rawValue
chicken.binary()

let pears = checkList & CheckList.Pears.rawValue
pears.binary()

let apples = checkList & CheckList.Apples.rawValue
apples.binary()
*/
