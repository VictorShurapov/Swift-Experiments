//1
let str1 = "14ah"
let str2 = "184tky"
let str3 = "56"
let str4 = "28"
let str5 = "11"

var sum = 0

if str1.toInt() != nil {
    sum = sum + str1.toInt()!
}

if let actualNumber2 = str2.toInt() {
    sum = sum + actualNumber2
}

if let actualNumber3 = str3.toInt() {
    sum = sum + actualNumber3
}

if str4.toInt() != nil {
    sum = sum + str4.toInt()!
}

if let actualNumber5 = str5.toInt() {
    sum = sum + actualNumber5
}

println("sum = \(sum)")
println("====================================")

//2
let serverResponse: (statusCode: Int, message: String?, errorMessage: String?) = (300, nil, "Error!")
let statusCode = serverResponse.statusCode
if statusCode >= 200 && statusCode < 300 {
    println(serverResponse.message!)
} else {
    println(serverResponse.errorMessage!)
}


let (_, message, errorMessage) = serverResponse
if message == nil {
    println("Message is \(message)")
}


if let errorMessageValue = errorMessage {
    println("Server`s response is \(errorMessageValue)")
}
println("====================================")

//3

var student1 : (name: String!, carPlate: String?, grade: String?)
var student2 : (name: String!, carPlate: String?, grade: String?)
var student3 : (name: String!, carPlate: String?, grade: String?)
var student4 : (name: String!, carPlate: String?, grade: String?)
var student5 : (name: String!, carPlate: String?, grade: String?)


student1.name = "Vasya"
student2.name = "Petya"
student3.name = "Kolya"
student4.name = "Nastya"
student5.name = "Vitya"

student1.carPlate = "gfdjkg43"
student2.carPlate = "sdafjds2"

student2.grade = "5"
student4.grade = "5"
student5.grade = "0"

//student1
println("First student`s name is \(student1.name)")
if student1.carPlate != nil {
    println("Student`s car plate number is \(student1.carPlate!)")
} else {
    println("He has no car")
}
if let student1Grade = student1.grade {
    println("Student`s grade is \(student1.grade)")
} else {
    println("\(student1.name) was absent")
}
println("====================================")

//student2
println("Second student`s name is \(student2.name)")
if student2.carPlate != nil {
    println("Student`s car plate number is \(student2.carPlate!)")
} else {
    println("He has no car")
}
if let student2Grade = student2.grade {
    println("Student`s grade is \(student2Grade)")
} else {
    println("\(student2.name) was absent")
}
println("====================================")

//student3
println("Third student`s name is \(student3.name)")
if student3.carPlate != nil {
    println("Student`s car plate number is \(student3.carPlate!)")
} else {
    println("He has no car")
}
if let student3Grade = student3.grade {
    println("Student`s grade is \(student3Grade)")
} else {
    println("\(student3.name) was absent")
}
println("====================================")

//student4
println("Fourth student`s name is \(student4.name)")
if student4.carPlate != nil {
    println("Student`s car plate number is \(student4.carPlate!)")
} else {
    println("She has no car")
}
if let student4Grade = student4.grade {
    println("Student`s grade is \(student4Grade)")
} else {
    println("\(student4.name) was absent")
}
println("====================================")

//student5
println("Fifth student`s name is \(student5.name)")
if student5.carPlate != nil {
    println("Student`s car plate number is \(student5.carPlate!)")
} else {
    println("He has no car")
}
if let student5Grade = student5.grade {
    println("Student`s grade is \(student5Grade)")
} else {
    println("\(student5.name) was absent")
}










