class Human {
    
    var firstName : String = ""
    var lastName : String = ""
    
    var fullName : String {
        return firstName + " " + lastName
    }
    
    func sayHello() -> String {
        return "Hello"
    }
}

class SmartHuman : Human {
    
}


class Student : SmartHuman {
    override func sayHello() -> String {
        return super.sayHello() + ", my friend" // operator `super`
    }
}

class Kid : Human {
    
    final var favoriteToy : String = "iMac" // final
    
    override func sayHello() -> String {
        return "agu" // - override переопределение
    }
    
    override var fullName : String {
        return firstName
    }
    
    override var firstName : String {
        set {
            super.firstName = newValue + " :-)"
        }
        get {
            return super.firstName
        }
    }
    
    override var lastName : String {
        didSet {
            println("new value " + self.lastName)
        }
    }
}
// - overload перегрузка метода, тоже самое название метода, сабскрипта но другие параметры

let human = Human()
human.firstName = "Alex"
human.lastName = "Skutarenko"
human.sayHello()
human.fullName

let student = Student()
student.firstName = "Max"
student.lastName = "Ix"
student.sayHello()
student.fullName

let kid = Kid()
kid.firstName = "Vasya"
kid.lastName = "123"
kid.sayHello()
kid.fullName



let array = [kid, student, human]

for value in array {
    println(value.sayHello())
}
