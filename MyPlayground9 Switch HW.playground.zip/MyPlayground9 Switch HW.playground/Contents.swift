var text = "On the morning of 12 October 1978, Vicious claimed to have awoken from a drugged stupor to find Nancy Spungen dead on the bathroom floor of their room in the Hotel Chelsea in Manhattan, New York. She had suffered a single stab wound to her abdomen and appeared to have bled to death. The knife used had been bought by Vicious on 42nd Street and was identical to a ''007'' flip-knife given to punk rock vocalist Stiv Bators of the Dead Boys by Dee Dee Ramone. According to Dee Dee's wife at the time, Vera King Ramone, Vicious had bought the knife after seeing Stiv's.[21] Vicious was arrested and charged with her murder.[22] He said they had fought that night but gave conflicting versions of what happened next, saying, ''I stabbed her, but I never meant to kill her'', then saying that he did not remember and at one point during the argument Spungen had fallen onto the knife.[23]"

/*var vowels = 0
var consonants = 0
var symbols = 0
var numbers = 0
var count = 0
var spaces = 0*/

text = text.lowercaseString

var counts = (vowels: 0, consonants: 0, numbers: 0, symbols: 0)

for char in text {
    switch char {
    case "a", "e", "i", "o", "u", "A", "E","I", "O", "U": ++counts.vowels
    case "b", "c", "d", "f", "g", "h", "j", "k", "l", "m",
    "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z", "B", "C", "D", "F", "G", "H", "J", "K", "L", "M", "N", "P", "Q", "R", "S", "T", "V", "W", "X", "Y", "Z": ++counts.consonants
    case "0", "1", "2", "3", "4", "5", "6", "7", "8", "9": ++counts.numbers
    default: ++counts.symbols
    }
}
var count = counts.vowels + counts.consonants + counts.symbols + counts.numbers
println("There are \(counts.vowels) vowels, \(counts.consonants) consonants, \(counts.symbols) symbols, \(counts.numbers) numbers and \(count) characters in the text.")

//2

var age = 0

life: for i in 0...110 {
    switch age {
    case 0...2: println("age - \(age) - newborn")
    case 3...6: println("age - \(age) - kid")
    case 7...13: println("age - \(age) - child")
    case 13...19: println("age - \(age) - teen")
    case 19...110: println("age - \(age) - kidult"); break life
    default: break
    }
    age = age + 5
}

//3

var name = (name: "Анастасия", patronymic: "Николаевна", surname: "Очкольда")

switch name {
case _ where name.name.hasPrefix("А") || name.name.hasPrefix("О"):
println("Привет, \(name.name)!")
    
case _ where name.patronymic.hasPrefix("В") || name.patronymic.hasPrefix("Д"):
println("Привет, \(name.name) \(name.patronymic)!")
    
case _ where name.surname.hasPrefix("Е") || name.surname.hasPrefix("З"):
    println("Привет, \(name.surname)!")
    
default:
println("Привет, \(name.name) \(name.patronymic) \(name.surname)!")
}

//4.1 light version

let point = (x: 2, y: 4)

switch point {
case (2, 2...5): println("Wounded")
case (5, 5...7): println("Wounded")
case (3, 3), (1, 1), (8, 8): println("Killed")
case (10, 6...10): println("Wounded")
default: println("Missed")
}

//4.2 full version

var oneDeckShip_1 = (x: 7, y:3, height: 1, width: 1, hits: 0) // hits - счетчик попаданий
var oneDeckShip_2 = (x: 2, y:6, height: 1, width: 3, hits: 2)
var oneDeckShip_3 = (x: 8, y:7, height: 3, width: 1, hits: 1)

var fleet = [oneDeckShip_1,  oneDeckShip_2,  oneDeckShip_3]

let shot = (x: 8, y: 8)
println("Shot at the point (\(shot.x), \(shot.y))")
var returningString = ""

gameLoop: for (unit, ship) in enumerate(fleet) {
    let x1 = ship.x, x2 = ship.x + (ship.width - 1)
    let y1 = ship.y, y2 = ship.y + (ship.height - 1)
    let sizeOfShip = ship.height * ship.width

    switch shot {
        
    case (x1...x2, y1...y2) where ship.hits == sizeOfShip - 1:
        returningString = "Kill!"
        
    case (x1...x2, y1...y2):
        returningString = "Wounded!"
        ++fleet[unit].hits
        continue gameLoop
        
    default:
        returningString = "Missed!"
    }
}
println(returningString)
