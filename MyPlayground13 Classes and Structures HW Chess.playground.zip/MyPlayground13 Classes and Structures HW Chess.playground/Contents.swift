//007
import UIKit

enum Color : String {
    case White = "White"
    case Black = "Black"
}

enum pieceName : String {
    case King = "King"
    case Queen = "Queen"
    case Bishop = "Bishop"
    case Knight = "Knight"
    case Rook = "Rook"
    case Pawn = "Pawn"
}

typealias Pos = (x: Character, y: Int)

class ChessFigures : NSObject {
    var position : Pos
    var color : Color
    var name : pieceName
    
    init (color: Color, position: Pos, name: pieceName) {
        self.color = color
        self.position = position
        self.name = name
    }
    
    func chessInfo() {
        println("\(color.rawValue) \(name.rawValue) on \(position)")
    }
    
    func piecePrint() -> Character? {
        switch (self.name, self.color) {
        case (.King, .White): return "♔"
        case (.King, .Black): return "♚"
        case (.Queen, .White): return "♕"
        case (.Queen, .Black): return "♛"
        case (.Bishop, .White): return "♗"
        case (.Bishop, .Black): return "♝"
        case (.Knight, .White): return "♘"
        case (.Knight, .Black): return "♞"
        case (.Rook, .White): return "♖"
        case (.Rook, .Black): return "♜"
        case (.Pawn, .White): return "♙"
        case (.Pawn, .Black): return "♟"
        default : return nil
        }
    }
    
    func move(newPosition: Pos) -> Bool {
        switch newPosition {
        case ("a"..."h", 1...8): position = newPosition
        default: println("Position \(newPosition) is out of board!")
        return false
        }
        return true
    }
}

func drawChessBoard(figures: [ChessFigures]) {
    func figure(pos: Pos) -> Character? {
        for val in figures {
            if pos.x == val.position.x && pos.y == val.position.y {
                return val.piecePrint()
            }
        }
        return nil
    }
    let hor = "abcdefgh"
    let ver = 1...8
    
    for i in ver {
        println("\(9-i)")
        for (j, x) in enumerate(hor) {
            if let figure = figure((x, 9 - i)) {
                println("\(figure) ")
                continue
            }
            print(i % 2 == j % 2 ? "■" : "□")
        }
        println()
    }
    println(" a b c d e f g h")
}

let f1 = ChessFigures(color: .White, position: ("a", 1), name: .King)
let f2 = ChessFigures(color: .Black, position: ("c", 2), name: .King)
let f3 = ChessFigures(color: .Black, position: ("h", 3), name: .Rook)

var chessFigure = [f1, f2, f3]

drawChessBoard(chessFigure)