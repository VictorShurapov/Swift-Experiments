// ~ ~ Classes and Structures
// ~ Comparing Classes and Structures

// `Defenition Syntax`

/*
class SomeClass {
    
}
struct SomeStructure {
    
}
*/

struct Resolution {
    var width = 0 // <-  stored properties
    var height = 0 // <- _
}

class VideoMode {
    var resolution = Resolution() // <- initialized with a new Resolution structure instance
    var interlaced = false
    var frameRate = 0.0
    var name: String? // <- default value of nil or "no name value"
}


// `Class and Structure Instances

let someResolution = Resolution()
let someVideoMode = VideoMode()


// `Accessing Properties` - dot syntax

println("The width of someResolution is \(someResolution.width)")

println("The width of SomeVideoMode is \(someVideoMode.resolution.width)")

someVideoMode.resolution.width = 1280
println("The width of someVideoMode is now \(someVideoMode.resolution.width)")


// ` Memberwise Initializers for Structure Types

let vga = Resolution(width: 640, height: 480)


// ~ Structures and Enumerations Are Value Types

let hd = Resolution(width: 1920, height: 1080)
var cinema = hd
cinema.width = 2048
println("cinema is now \(cinema.width) pixels wide")
println("hd is still \(hd.width) pixels wide")

enum CompassPoint {
    case North, South, East, West
}
var currentDirection = CompassPoint.West
let rememberedDirection = currentDirection
currentDirection = .East
if rememberedDirection == .West {
    println("The remembered direction is still .West")
}


// ~ Classes Are Reference Types

let tenEighty = VideoMode()
tenEighty.resolution = hd
tenEighty.interlaced = true
tenEighty.name = "1080i"
tenEighty.frameRate = 25.0

let alsoTenEighty = tenEighty
alsoTenEighty.frameRate = 30.0

println("The frameRate property of tenEighty is now \(tenEighty.frameRate)")

// `Identity Operators

// Identical to(===)
// Not identical to(!==)

if tenEighty === alsoTenEighty {
    println("tenEighty and alsoTenEighty refer to the same VideoMode instance.")
}
