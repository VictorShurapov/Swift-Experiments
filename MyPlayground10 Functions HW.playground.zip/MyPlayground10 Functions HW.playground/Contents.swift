//1

func heart() -> String {
    return "\u{1F496}"
}
func skull() -> String {
    return "\u{1F480}"
}
func alien() -> String {
    return "\u{1F47D}"
}

func boom() -> String {
    return "\u{1F4A5}"
}
func moneyBag() -> String {
    return "\u{1F4B0}"
}
println(heart() + skull() + alien() + boom() + moneyBag())
println("================================================\n")


//2

func waxmati(char: String, num: Int) -> String {
    let chars = ["A": 1, "B": 2, "C": 3, "D": 4, "E": 5, "F": 6, "G": 7, "H": 8]
    if num % 2 == chars[char]! % 2 {
        return "Black"
    } else {
        return "White"
    }
}

println(waxmati("B", 6))
println("================================================\n")



//3 
func reverseArray(array: [Any]) -> [Any] {
    var tempArray : [Any] = []
    for obj in array {
        tempArray.insert(obj, atIndex: 0)
    }
    

    return tempArray
}

let a1 = reverseArray([1, 2, 3, 4, 5])

func fastReverse(array: [Any]) -> [Any] {
    return reverse(array)

}

let a1Fast = fastReverse(["q", "w", "e", "r", "t", "y"])
println(a1Fast)
println("================================================\n")

//3.1

func reversedArrayFromSequence(sequence: Any...) -> [Any] {
var array = [Any]()
for i in sequence {
    array += [i]
}


return reverseArray(array)
}

let a2 = reversedArrayFromSequence(1, 2, 3, 4, 5)

//4
func inoutReverse(inout array: [Int]) {
    for obj in array {
        array.insert(obj, atIndex: 0)
        array.removeLast()
    }
}

var inoutArray = [1, 2, 3, 4, 5,]
inoutReverse(&inoutArray)

println(inoutArray)
println("================================================\n")



//5

var string = "Closures are self-contained blocks of functionality that can be passed around and used in your code. Closures in Swift are similar to blocks in C and Objective-C and to lambdas in other programming languages. 0. 1. 2 3 4 5 6 7 8. 9"
println(string)

func changedString(inout string: String) {
    let digits = [0: "zero", 1: "one", 2: "two", 3: "three", 4: "four", 5: "five", 6: "six", 7: "seven", 8: "eight", 9: "nine"]
    for char in string.lowercaseString {
        let char = String(char)
        switch char {
            case "a", "e", "i", "o", "u":
            string += char.uppercaseString
            case "b"..."z":
            string += char
            case "0"..."9":
            let key = char.toInt()!
            string += digits[key]!
            
        default:
            let space: Character = " "
            string += String(space)
        }
        string.removeAtIndex(string.startIndex)
    }
}

changedString(&string)

println("================================================\n")
println(string)
