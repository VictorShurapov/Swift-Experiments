struct Point {
    var x : Int
    var y : Int
    /*
    mutating func moveByX(x: Int, andY y: Int) {
    self.x += x
    self.y += y
    }
    */
    
    mutating func moveByX(x: Int, andY y: Int) {
        self = Point(x: self.x + x, y: self.y + y)
    }
}


var p = Point(x: 1, y: 1)

p.moveByX(5, andY: 7)


enum Color {
    
    static func numberOfElements() ->Int {
        self.print()
        return 2
    }
        case White
        case Black
        
        mutating func invert() -> Color {
            /*if self == White {
            self = Black
            } else {
            self = White
            }*/
            self = self == White ? Black : White
            self.print()
            //Color.print()
            return self
        }
        
        func print() {
            self == White ? println("White") : println("Black")
        }
    static func print() {
        println("enum")
    }
    }
    
    var c = Color.White
    
    
    c.print()
    c.invert()
    c.print()
    
    println()
    c.invert().print()
    c.invert().print()
    c.invert().print()

println(Color.numberOfElements())