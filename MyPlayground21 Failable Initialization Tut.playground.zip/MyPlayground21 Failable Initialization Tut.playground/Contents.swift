// ~ ~ Failable Initialization

struct Animal {
    let species: String
    init?(species: String) {
        if species.isEmpty {  return nil }
        self.species = species
    }
}

let someCreature = Animal(species: "Giraffe")
if let giraffe = someCreature {
    println("An animal was initialized with a species of \(giraffe.species)")
}

let anonymousCreature = Animal(species: "")
if anonymousCreature == nil {
    println("The anonymous creature could not be initialized")
}


// Failable Initializers for Enumerations

enum TemperatureUnit {
    case Kelvin, Celsius, Fahrenheit
    init?(symbol: Character) {
        switch symbol {
        case "K":
            self = .Kelvin
        case "C":
            self = .Celsius
        case "F":
            self = .Fahrenheit
        default:
            return nil
        }
        
    }
}

let fahrenheitUnit = TemperatureUnit(symbol: "F")
if fahrenheitUnit != nil {
    println("This is a defined temperature unit, so initialization succeeded.")
}

let unknowUnit = TemperatureUnit(symbol: "X")
if unknowUnit == nil {
    println("This is not a defined temperature unit, so initialization failed.")
}

// Failable Initializers for Enumeration with Raw Values

enum TemperatureUnitRaw: Character {
    case Kelvin = "K", Celsius = "C", Fahrenheit = "F"
}

let fahrenheitUnit1 = TemperatureUnitRaw(rawValue: "F")
if fahrenheitUnit1 != nil {
    println("This is a defined temperature unit, so initialization secceeded.")
}

let unknowUnit1 = TemperatureUnitRaw(rawValue: "X")
if unknowUnit1 == nil {
    println("This is not a defined temperature unit, so initialization failed.")
}


// Failable Initializers for Classes

class Product {
    let name: String!
    init?(name: String) {
        self.name = name
        if name.isEmpty { return nil }
    }
}


if let bowTie = Product(name: "bow tie") {
    println("The product`s name is \(bowTie.name)")
}


// Propagation of Initialization Failure

class CartItem: Product {
    let quantity: Int!
    init?(name: String, quantity: Int) {
        self.quantity = quantity
        super.init(name: name)
        if quantity < 1 { return nil }
    }
}

if let twoSocks = CartItem(name: "sock", quantity: 2) {
    println("Item: \(twoSocks.name), quantity: \(twoSocks.quantity)")
}

if let zeroShirts = CartItem(name: "shirt", quantity: 0) {
    println("Item: \(zeroShirts.name), quantity: \(zeroShirts.quantity)")
} else {
    println("Unable to initialize zero shirts")
}

if let oneUnnamed = CartItem(name: "", quantity: 1) {
    println("Item: \(oneUnnamed.name), quantity: \(oneUnnamed.quantity)")
} else {
    println("Unable to initialize one unnamed product")
}


// Overriding a Failable Initializer

class Document {
    var name: String?
    init() {}
    init?(name: String) {
        self.name = name
        if name.isEmpty { return nil }
    }
}

class AutomaticallyNamedDocument: Document {
    override init() {
        super.init()
        self.name = "[Untitled]"
    }
    override init?(name: String) {
        super.init()
        if name.isEmpty {
            self.name = "[Untitled]"
        } else {
            self.name = name
        }
    }
}

// Required Initializers

class SomeClass {
    required init() {
        // init goes here
    }
}

class SomeSubclass: SomeClass {
    required init() {
        super.init() // subclass implementation of the required initializer goes here
    }
}


// ~ ~ Setting a Default Property Value with a Closure or Function

/*
class SomeCLass1 {
let someProperty: SomeType = {
// create a default value for someProperty inside this closure
// comeValue must be of the same type as SomeType
return SomeValue
}()
}
*/

struct Checkerboard {
    let boardColors: [Bool] = {
        var temporaryBoard = [Bool]()
        var isBlack = false
        for i in 1...10 {
            for j in 1...10 {
                temporaryBoard.append(isBlack)
                isBlack = !isBlack
            }
            isBlack = !isBlack
        }
        return temporaryBoard
        }()
    func squareIsBlackAtRow(row: Int, column: Int) -> Bool {
        return boardColors[(row * 10) + column]
    }
}

let board = Checkerboard()
println(board.squareIsBlackAtRow(4, column: 4))
println(board.squareIsBlackAtRow(5, column: 4))