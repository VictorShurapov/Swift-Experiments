// 1. Для нашей структуры Point перегрузить операторы: -, -=, prefix —, prefix —-, postfix —-, /, /=, *=

struct Point {
    var x: Int
    var y: Int
}

// `-`
func - (a: Point, b: Point) -> Point {
return Point(x: a.x - b.x, y: a.y - b.y)
}

// `-=`
func -= (inout a: Point, b: Point) {
a = a - b
}

// `prefix -`
prefix func - (a: Point) -> Point {
return Point(x: -a.x, y: -a.y)
}

// `prefix --`
prefix func -- (inout a: Point) -> Point {
--a.x
--a.y
return a
}

// `postfix --`
postfix func -- (inout a: Point) -> Point {
let b = a
--a
return b
}

// `/`
func / (a: Point, b: Point) -> Point {
return Point(x: a.x / b.x, y: a.y / b.y)
}

// `*`
func * (a: Point, b: Point) -> Point {
return Point(x: a.x * b.x, y: a.y * b.y)
}

// `/=`
func /= (inout a: Point, b: Point) {
a = a / b
}

// `*=`
func *= (inout a: Point, b: Point) {
a = a * b
}

var p1 = Point(x: 1, y: 1)
var p2 = Point(x: 2, y: 3)

var a = p1 - p2

p2 -= p1

-p1

p2
--p2

p1
p1--
p1

p1 = Point(x: 1, y: 1)
p2 = Point(x: 2, y: 3)
var b = p1 / p2

p1 = Point(x: 1, y: 1)
p2 = Point(x: 2, y: 3)
p1 /= p2

p1 = Point(x: 1, y: 1)
p2 = Point(x: 2, y: 3)
p1 *= p2

// 2. Создать структуру Rect, аналог CGRect, содержащую структуру Size и Point. Перегрузить операторы +, +=, -, -= для этой структуры.

struct Size {
    var width: Int, height: Int
}
struct Rect {
    var origin = Point(x: 0, y: 0)
    var size = Size(width: 0, height: 0)
}

var r1 = Rect(origin: Point(x: 0, y: 0), size: Size(width: 2, height: 2))
var r2 = Rect(origin: Point(x: 2, y: 2), size: Size(width: 1, height: 1))

// `+`
func + (a: Rect, b: Rect) -> Rect {
    let point = Point(x: a.origin.x + b.origin.x, y: a.origin.y + b.origin.y)
    let size = Size(width: a.size.width + b.size.width, height: a.size.height + b.size.height)
    return Rect(origin: point, size: size)
}

var r3 = r1 + r2

// `-`
func - (a: Rect, b: Rect) -> Rect {
    let point = Point(x: a.origin.x - b.origin.x, y: a.origin.y - b.origin.y)
    let size = Size(width: a.size.width - b.size.width, height: a.size.height - b.size.height)
    return Rect(origin: point, size: size)
}

r1 = r3 - r2

// +=
func += (inout a: Rect, b: Rect) {
    a = a + b
}

r1 += r2

// -=
func -= (inout a: Rect, b: Rect) {
    a = a - b
}

r1 -= r2


//3. Перегрузить оператор + и += для String, но второй аргумент должен быть Int
func + (s: String, i: Int) -> String {
    return s + String(i)
}
func += (inout s: String, i: Int) {
    s = s + i
}

var str = "Three...Two..."
var int = 1
var threeTwoOne = str + int

//4. Создать свой оператор, который будет принимать 2 String и в первом аргументе, при совпадении буквы с вторым аргументом, менять совпадения на заглавные буквы

infix operator ^*^ {}
func ^*^ (inout s1: String, s2: String) {
    let set = Set(s2)
    for (i, ch) in enumerate(s1) {
        if set.contains(ch) {
            s1[i] = ch.uppercase
        }
    }
}

extension Character {
    var uppercase: Character {
        return Character(String(self).uppercaseString)
    }
}

extension String {
    subscript(i: Int) -> Character {
        get {
            return self[advance(self.startIndex, i)]
        }
        set {
            let start = advance(self.startIndex, i)
            let end = start.successor()
            self.replaceRange(Range(start: start, end: end), with: String(newValue))
        }
    }
}

var string = "Bose Salo!!"
string ^*^ "Nastyul`ka"