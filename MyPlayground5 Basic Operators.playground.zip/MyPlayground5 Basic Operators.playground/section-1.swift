
let total = 5 + 6 - 8 * 3 - 5 / 10

let div = 10 / 3
let rest = 13 % 3
let floatRest = 8 / 2.5
let floatRest2 = 8 % 2.5

4356367868567 % 101

var small : UInt8 = 0xff

// &+ &- &* &/ &%
small = small &+ 5

let str = "Hi," + "there!"

// >, <, >=, <=, ==, !=, ===, !==

let a = 6
let b = 5

if a == b {
    println("yes")
} else {
    println("no")
}

var c : Int
/*
if a > b {
    c = a
} else {
    c = b
}
*/


c = a < b ? a : b

let text = "134"

let n = text.toInt()

/*
if n != nil {
    c = n!
} else {
    c = 0
}
*/

/*
if let opt = n {
    c = opt
} else {
    c = 0
}
*/

c = n ?? 0

var sum = 5
sum = sum + 1
sum += 1

sum++
sum
++sum

--sum
sum--
sum

var good = true
good = !good
// && = *, || = +
if good {
    println("good")
} else {
    println("bad")
}

/*
true && true = true
true && false = false

true || true = true
true || false = false
&& priority
*/

let i = 5
let j = 6
let k = 7
let m = 8

if  i > 3 && j < k && m != k || m > i {
    println("nice")
}

//range
0...5
0..<5

for i in 0..<5 {
    println("\(i)")
}







