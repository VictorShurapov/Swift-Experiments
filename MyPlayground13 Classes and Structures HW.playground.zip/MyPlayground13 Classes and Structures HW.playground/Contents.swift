//1. Создайте структуру студент. Добавьте свойства: имя, фамилия, год рождения, средний бал. Создайте несколько экземпляров этой структуры и заполните их данными. Положите их всех в массив (журнал).

struct Student {
    var name : String
    var surname : String
    var yearOfBirth : Int
    var gpa : Int
}

var student1 = Student(name: "Vasya", surname: "Petrenko", yearOfBirth: 1990, gpa: 4)
var student2 = Student(name: "Petya", surname: "Dort", yearOfBirth: 1988, gpa: 6)
var student3 = Student(name: "Sasha", surname: "Petrenko", yearOfBirth: 1995, gpa: 3)
var journal = [student1, student2, student3]
//2. Напишите функцию, которая принимает массив студентов и выводит в консоль данные каждого. Перед выводом каждого студента добавляйте порядковый номер в “журнале”, начиная с 1.

func printJournal(array: [Student]) {
    var count = 1
    for student in array {
println("\(count++): \(student.name) \(student.surname) \(student.yearOfBirth) \(student.gpa)")
    }
}

println("#  Name  Surname YOB GPA")
printJournal(journal)

//3. С помощью функции sorted отсортируйте массив по среднему баллу, по убыванию и распечатайте “журнал”.

var reversedGpa = sorted(journal) { $0.gpa > $1.gpa }
println("\nReversed GPA")
printJournal(reversedGpa)


//4. Отсортируйте теперь массив по фамилии (по возрастанию), причем если фамилии одинаковые, а вы сделайте так чтобы такое произошло, то сравниваются по имени. Распечатайте “журнал”.s

var sortedBySurname = sorted(journal) { first, second in
    if first.surname == second.surname {
        return first.name < second.name
    } else {
        return first.surname < second.surname
    }
}
println("\nSorted By Name")
printJournal(sortedBySurname)

//5. Создайте переменную и присвойте ей ваш существующий массив. Измените в нем данные всех студентов. Изменится ли первый массив? Распечатайте оба массива.

var newJournal = journal
newJournal[0].surname = "Doroshenko"
newJournal[0].name = "Petro"
newJournal[0].yearOfBirth = 1992
newJournal[0].gpa = 6

newJournal[1] = Student(name: "Vitek", surname: "Sulyapov", yearOfBirth: 1991, gpa: 16)
newJournal[2] = Student(name: "Genya", surname: "Rudenko", yearOfBirth: 1998, gpa: 12)

println("\nOriginal journal")
printJournal(journal)
println("\nNew journal")
printJournal(newJournal)

//6. Теперь проделайте все тоже самое, но не для структуры Студент, а для класса. Какой результат в 5м задании? Что изменилось и почему?
//6.1

class StudentClass {
    var name : String
    var surname : String
    var yearOfBirth : Int
    var gpa : Int
    init(name: String, surname: String, yearOfBirth: Int, gpa: Int) {
    self.name = name
    self.surname = surname
    self.yearOfBirth = yearOfBirth
    self.gpa = gpa
    }
}

var stClass1 = StudentClass(name: "Vasya", surname: "Petrenko", yearOfBirth: 1990, gpa: 4)
var stClass2 = StudentClass(name: "Petya", surname: "Dort", yearOfBirth: 1988, gpa: 6)
var stClass3 = StudentClass(name: "Sasha", surname: "Petrenko", yearOfBirth: 1995, gpa: 3)
var journalClass = [stClass1, stClass2, stClass3]

//6.2
func printJournal(array: [StudentClass]) {
    var count = 1
    for student in array {
        println("\(count++): \(student.name) \(student.surname) \(student.yearOfBirth) \(student.gpa)")
    }
}

println("===========================\n\nClass Variant\n#  Name  Surname YOB GPA")
printJournal(journalClass)

//6.3
var reversedGpaClass = sorted(journal) { $0.gpa > $1.gpa }
println("\nReversed GPA")
printJournal(reversedGpa)

//6.4
var sortedBySurnameClass = sorted(journal) { first, second in
    if first.surname == second.surname {
        return first.name < second.name
    } else {
        return first.surname < second.surname
    }
}
println("\nSorted By Name")
printJournal(sortedBySurname)


//6.5
var newJournalClass = journalClass

newJournalClass[0].surname = "Doroshenko"
newJournalClass[0].name = "Petro"
newJournalClass[0].yearOfBirth = 1992
newJournalClass[0].gpa = 6

newJournalClass[1] = StudentClass(name: "Vitek", surname: "Sulyapov", yearOfBirth: 1991, gpa: 16)
newJournalClass[2] = StudentClass(name: "Genya", surname: "Rudenko", yearOfBirth: 1998, gpa: 12)

println("\nOriginal journal")
printJournal(journalClass)
println("\nNew journal")
printJournal(newJournalClass)
