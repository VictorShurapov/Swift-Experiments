import Foundation
//1
let const1 = "2hjk"
let const2 = "5"
let const3 = "2"
let const4 = "j4"
let const5 = "3"

let intValue1 = const1.toInt() ?? 0
let intValue2 = const2.toInt() ?? 0
let intValue3 = const3.toInt() ?? 0
let intValue4 = const4.toInt() ?? 0
let intValue5 = const5.toInt() ?? 0

let sum = intValue1 + intValue2 + intValue3 + intValue4 + intValue5
let sumInterpolation = "\(intValue1) + \(intValue2) + \(intValue3) + \(intValue4) + \(intValue5) = \(sum)"
println(sumInterpolation)

let intV1 = (const1.toInt() != nil) ? const1 : "nil"
let intV2 = (const2.toInt() != nil) ? const2 : "nil"
let intV3 = (const3.toInt() != nil) ? const3 : "nil"
let intV4 = (const4.toInt() != nil) ? const4 : "nil"
let intV5 = (const5.toInt() != nil) ? const5 : "nil"

let sumConcatenation = intV1 + " + " + intV2 + " + " + intV3 + " + " + intV4 + " + " + intV5
let sumConcatenation2 = "sumConcatenation" + " = " + "\(sum)"
println("\(sumConcatenation) = \(sum)")

//2
let char1 : Character = "\u{263B}"
let char2 : Character = "\u{2763}"
let char3 : Character = "\u{0024}"
let char4 : Character = "\u{2622}"
let char5 : Character = "\u{1F48C}"
let char6 : Character = "\u{1F63A}"
let char7 : Character = "\u{1F4A5}"
let char8 : Character = "\u{1F300}"
let funString = "\u{263B}\u{2763}\u{0024}\u{2622}\u{1F48C}\u{1F63A}\u{1F4A5}\u{1F300}"

println("Swift`s method length is \(count(funString))")
(funString as NSString).length
println("Objective`s count = \((funString as NSString).length)")

//3
let alphabet = "abcdefghijklmnopqrstuvwxyz"
let myChar : Character = "v"
var countA = 1

for i in alphabet {
    if myChar == i {
        println("Letter '\(myChar)' is '\(countA)' in alphabet")
    }
    countA++
}
