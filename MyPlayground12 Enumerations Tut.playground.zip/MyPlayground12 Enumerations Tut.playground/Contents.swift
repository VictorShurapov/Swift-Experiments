// ~ ~ Enumerations. Enumerations Syntax

//cmd+A -> ctrl + I

enum SomeEnumeration {
    //enumeration definition goes here
}

enum CompassPoint {
    case North // <-- member value or member
    case South
    case East
    case West
}
//Multiple member values on a single line

enum Planet {
    case Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
}

var directionToHead = CompassPoint.West
directionToHead = .East


// ~ Matching Enumeration Values with a Switch Statement
directionToHead = .South
switch directionToHead {
case .North:
    println("Lots of planet have a north")
case .South:
    println("Watch out for penguins")
case .East:
    println("Where the sun rises")
case .West:
    println("Where the skies are blue")
}

let somePlanet = Planet.Earth
switch somePlanet {
case .Earth:
    println("Mostly harmless")
default:
    println("Not a safe place for humans")
}


// ~ Associated Values

enum Barcode {
    case UPCA(Int, Int, Int, Int)
    case QRCode(String)
}

var productBarcode = Barcode.UPCA(8, 85909, 51226, 3)
productBarcode = .QRCode("ABCDEFGHIJKLMNOP")

switch productBarcode {
case .UPCA(let numberSystem, let manufacturer, let product, let check):
    println("UPC-A: \(numberSystem), \(manufacturer), (product), (check).")
case .QRCode(let productCode):
    println("QR code: \(productCode).")
}

// If all of the associated values for an enumeration member are extracted as constants/variables -let/var before the member name:
switch productBarcode {
case let .UPCA(numberSystem, manufacturer, product, check):
    println("UPC-A: \(numberSystem), \(manufacturer), \(product), \(check).")
case let .QRCode(productCode):
    println("QR code: \(productCode).")
}

// ~ Raw Values
enum ASIIControlCharacter: Character {
    case Tab = "\t"
    case LineFeed = "\n"
    case CarriageReturn = "\r"
}

enum Planet2: Int {
    case Mercury = 1, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
}
// access the raw value of enumeration member with its rawValue property:
let earthsOrder = Planet2.Earth.rawValue
//Initializing from a Raw Value
let possiblePlanet = Planet2(rawValue: 7)

let positionToFind = 9
if let somePlanet = Planet2(rawValue: positionToFind) {
    switch somePlanet {
    case .Earth:
        println("Mostly harmless")
    default:
        println("Not safe place for humans")
    }
} else {
    println("There isn't a planet at position \(positionToFind)")
}
