//import Foundation

class Address {
    
    var street = "Deribasovskaya"
    var number = "1"
    var city = "Odessa"
    var country = "Ukraine"
}

struct Garage {
    var size = 2
}

class House {
    
    var rooms = 1
    var address = Address()
    var garage : Garage? = Garage()
}

class Car {
    var model = "Zaporojec"
    
    func start() {
    }
}


class Person {
    
    var cars : [Car]? = [Car()]
    var house : House? = House()
}

let p = Person()

//p.cars![0]
//p.house!

if (p.house?.garage?.size = 3) != nil {
    println("Upgrade!")
} else {
    println("Failure!")
}

if let house = p.house {
    if let garage = house.garage {
        garage.size
    }
}

if let size = p.house?.garage?.size {
    size
}

//p.cars?[0].model

if p.cars?[0].start() != nil {
    println("start!")
} else {
    println("failure!")
}



/////////////////

class Symbol {
}

class A: Symbol {
    func aa(){}
}

class B: Symbol {
    func  bb(){}
}

let array: [Any] = [A(), B(), Symbol(), A(), A(), B(), 5, "ff"]
//var aCount = 0
//var bCount = 0
//var sCount = 0

var cc = (aCount: 0, bCount: 0, sCount: 0)

//AnyObject
//Any
for value in array {
    if value is A {
        cc.aCount++
    } else if value is B {
        cc.bCount++
    } else {
        cc.sCount++
    }
    
    if value is String {
        println("String is there")
    }
    
    if let a = value as? A {
        a.aa()
    } else if let b = value as? B {
        b.bb()
    }
    
    //let a = value as! A
}

cc.aCount
cc.bCount
cc.sCount

