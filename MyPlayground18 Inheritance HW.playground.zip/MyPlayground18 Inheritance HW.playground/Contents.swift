//1
class Artist {
    
    var name : String
    var surname : String
    var fullname : String {
        return "\(name) \(surname)"
    }
    
    func performance() {
        println("\(fullname) with Perfomance!")
    }
    
    init(name: String, surname: String) {
        self.name = name
        self.surname = surname
    }
    
}

class Dancer : Artist {
    override func performance() {
        println("\(fullname) is dancing 💃 !!!")
    }
}

class Singer : Artist {
    override func performance() {
        println("\(fullname) is singing 🎤 !!!")
    }
}

class Musician : Artist {
    override func performance() {
        println("\(fullname) is rocking 🎺 !!!")
    }
}

class Painter : Artist {
    
    override var name : String {
        set {
            super.name = "My"
        }
        get {
            return super.name
        }
    }
    
    override var surname : String {
        set {
            super.surname = "World"
        }
        get {
            return super.surname
        }
    }
    
    override init(name: String, surname: String) {
        super.init(name: "My", surname: "World")
    }
    override func performance() {
        println("\(fullname) is painting 🎨 !!!")
    }
}

let dancer = Dancer(name: "Vi", surname: "Tya")
let singer = Singer(name: "Nas", surname: "Tya")
let dude = Musician(name: "Du", surname: "De")
let painter = Painter(name: "Kra", surname: "Sava")

let crew = [dancer, singer, dude, painter]

for i in crew {
    i.performance()
}
println()


//2
class Vehicle {
    
    var speed : Double {
        return 0
    }
    var capacity : Double {
        return 0
    }
    var fare : Double {
        return 0
    }
    
    var type : String {
        return ""
    }
    
    func priceForTrack(km: Double, numberOfPas: Double) {
        
        let trip = numberOfPas > capacity ? (numberOfPas / capacity) : 1
        let time = km / speed * trip
        let money = fare * trip * numberOfPas
        
        println("To transfer by \(type) \(numberOfPas) persons per \(km)km you need to pay \(money)$, spend \(time) hour(s) and take \(trip)trip(s).\n")
    }
}


class Plane : Vehicle {
    
    override var speed : Double {
        return 795
    }
    
    override var capacity : Double {
        return 240
    }
    
    override var fare : Double {
        return 350
    }
    
    override var type : String {
        return "Plane"
    }
    
}


class Ship : Vehicle {
    
    override var speed : Double {
        return 80
    }
    
    override var capacity : Double {
        return 500
    }
    
    override var fare : Double {
        return 400
    }
    
    override var type : String {
        return "Ship"
    }
}

class Car : Vehicle {
    
    override var speed : Double {
        return 160
    }
    
    override var capacity : Double {
        return 5
    }
    
    override var fare : Double {
        return 150
    }
    
    override var type : String {
        return "Car"
    }
}

class Train : Vehicle {
    
    override var speed : Double {
        return 330
    }
    
    override var capacity : Double {
        return 579
    }
    
    override var fare : Double {
        return 260
    }
    
    override var type : String {
        return "Train"
    }
}


let plane = Plane()
let ship = Ship()
let car = Car()
let train = Train()

let transport = [plane, ship, car, train]

for i in transport {
    i.priceForTrack(1000, numberOfPas: 100)
}
println()

//3

class Alive {
    
}

class Animals : Alive {
    
}

class Quadrupeds: Animals {
    
}

class Reptiles : Quadrupeds {
    
}

class Humans : Alive {
}

class Crocodiles : Reptiles {
}

class Monkeys : Quadrupeds {
    
}

class Dogs : Quadrupeds {
    
}

class Giraffes : Quadrupeds {
    
}

var count = (alive: 0, animals: 0, reptiles: 0, quadrupeds: 0)
let company = [Humans(), Crocodiles(), Monkeys(), Dogs(), Giraffes()]

for val in company {
    count.alive++
    
    if val is Animals {
        count.animals++
    }
    
    if val is Quadrupeds {
        count.quadrupeds++
    }
    
    if val is Reptiles {
        count.reptiles++
    }
}

println("Alive: \(count.alive)")
println("Animals: \(count.animals)")
println("Reptiles: \(count.reptiles)")
println("Quadrupeds: \(count.quadrupeds)")
