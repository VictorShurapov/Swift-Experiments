let constArray = ["a", "b", "c", "d"]
constArray.count

var array = [String]()

if array.count == 0 {
    println("array is empty")
}
array.isEmpty

array += constArray
array

array += ["e"]

array.append("f")

var array2 = array
array
array2

array2[0] = "1"
array
array2

//array[1...4] = ["0"]

array.insert("-", atIndex: 3)

array.removeAtIndex(3)
array

//let test = [Int](count: 10, repeatedValue: 100)
let money = [100, 1, 5, 20, 1, 50, 1, 1, 20, 1]

// example1
var sum = 0
for var i = 0; i < 9; i++ {
    //println("i = \(i)")
    sum += money[i]
}
sum

//  example2
sum = 0

for var i = 0; i < money.count; i++ {
    //println("i = \(i)")
    sum += money[i]
}
sum

//example3 ++
sum = 0

for i in 0..<money.count {
    println("index = \(i) value = \(money[i])")
    sum += money[i]
}
sum

//example4
for i in money{
    println("i = \(i)")
    sum += i
}
sum

//example5
sum = 0
var index = 0
for value in money{
    println("index = \(index) value = \(value)")
    sum += value
    index++
}
sum

//example6
sum = 0

for (index, value) in enumerate(money) {
    println("index = \(index) value = \(value)")
    sum += value
}
sum
