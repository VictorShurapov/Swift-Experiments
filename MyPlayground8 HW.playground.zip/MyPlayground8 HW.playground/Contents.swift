//1

var studBook = ["Nastya Lovely": 5, "Vitya Shu": 4, "Vasya Hitl": 8, "Sid Vicious": 2, "Britney Spearmint": 1]

//1.1

studBook["Vasya Hitl"] = 88
studBook.updateValue(3, forKey: "Sid Vicious")
studBook["Britney Spearmint"] = 2

//1.2

studBook["Sasha Piu"] = 4
studBook["Alex Sku"] = 6

//1.3

studBook["Vasya Hitl"] = nil
studBook.removeValueForKey("Britney Spearmint")

//1.4

var sum = 0

for value in studBook.values {
    sum += value
}

var gpa = Double(sum) / Double(studBook.count)

println("Overall score is \(sum) and GPA is \(gpa)\n\n")

//2

let months = ["Jan": 31, "Feb": 28, "Mar": 31, "Apr": 30, "May": 31, "June": 30, "July": 31, "Aug": 31, "Sep": 30, "Oct": 31, "Nov": 30, "Dec": 31]
println("tuples\n")

for (key, value) in months {
    println("In \(key) - \(value) days")
}

println("\nkeys\n")

for key in months.keys {
    if let value = months[key] {
        println("In \(key) - \(value) days.")
    } else {
        println("No value for key \(key).")
    }
}

//3
println("\n\n\nchess board\n\n")

var chessBoard = [String: Bool]()
var letters = ["a", "b", "c", "d", "e", "f", "g", "h"]

print("  ")
for letter in letters {
    print("\(letter) ")
}
println()

for var number = letters.count; number >= 1; number-- {
    print("\(number) ")
    for letter in 0..<letters.count {
        let key = "\(letters[letter])\(number)"
        let value = (letter + number) % 2 == 0 ? true : false
        
        chessBoard[key] = value
        
        print((value ? "\u{25A1} " : "\u{25A0} "))
    }
    println("\(number)")
}


print("  ")
for letter in letters {
    print("\(letter) ")
}
println()
//false = black, true - white

chessBoard["a1"]
chessBoard["h8"]
chessBoard["c4"]
