////1
//func count10(closure: () -> ()) {
//    for i in 1...10 {
//        print("\(i) ")
//    }
//    closure()
//}
//
//count10{print("\nclosure there ;-)\n\n")}
//
////2
//
//let numbers = [3, 5, 4, 7, 8, 16, 88, 12]
//var descending = numbers.sort(>)
//var ascending = numbers.sort(<)
//print("Original, descending and ascending arrays - \(numbers), \(descending) and \(ascending)\n\n")
//
////3
//func findNumber(array: [Int], closure: (Int, Int?) -> Bool) -> Int {
//    var optValue : Int?
//    for value in array {
//        if closure(value, optValue) {
//            optValue = value
//        }
//    }
//    return optValue ?? 0
//}
//
//let max = findNumber(numbers) { $1 == nil || $0 > $1 }
//let min = findNumber(numbers) { $1 == nil || $0 < $1 }
//print("Max is \(max)")
//print("Min is \(min)\n\n")

//4
var array = "An enumeration DBCdefines a Common type for a group of related values and enables you to work with those values in a type-safe way within your code.987654321"
var arrayOfChar = Array(array.characters)

func priority (s: String) -> Int {
    switch s.lowercaseString {
    case "a", "e", "i", "o", "u", "y" : return 1
    case "b"..."z" : return 2
    case "0"..."9" : return 3
    default : return 4
    }
}

let sortedArray = arrayOfChar.sort() {
    switch (priority(String($0)), priority(String($1))) {
    case let (x, y) where x == y && String($0).uppercaseString == String($1).uppercaseString: return $0 < $1
        
    case let (x, y) where x == y: return String($0).uppercaseString < String($1).uppercaseString
        
    default: return priority(String($0)) < priority(String($1))
    }
}
print("\(sortedArray)")


////5
//var letters: [Character] = ["d", "b", "R", "p", "T"]
//var scalars = Array(String(letters).unicodeScalars).map { Int($0.value) }
//
//let maxScalar = findNumber(scalars) { $1 == nil || $0 > $1 }
//let minScalar = findNumber(scalars) { $1 == nil || $0 < $1 }
//print("Max scalar value is \(maxScalar) and it`s \"\(Character(UnicodeScalar(UInt32(maxScalar))))\"")
//print("Min scalar value is \(minScalar) and it`s \"\(Character(UnicodeScalar(UInt32(minScalar))))\"")
