//1

println("Minimum and maximum of Integer`s types\n")

println("Int8: \t from \(Int8.min) to \(Int8.max)")
println("UInt8: \t from \(UInt8.min) to \(UInt8.max)")

println("Int16: \t from \(Int16.min) to \(Int16.max)")
println("UInt16: \t from \(UInt16.min) to \(UInt16.max)")

println("Int32: \t from \(Int32.min) to \(Int32.max)")
println("UInt32: \t from \(UInt32.min) to \(UInt32.max)")

println("Int64: \t from \(Int64.min) to \(Int64.max)")
println("UInt64: \t from \(UInt64.min) to \(UInt64.max)")
println("\n")

//2

let intValue = 2
let floatValue : Float = 4.35
let doubleValue = 5.05

let sumI = Int(Double(intValue) + Double(floatValue) + doubleValue)
let sumOfInt = intValue + Int(floatValue) + Int(doubleValue)

let sumOfFloat = Float(intValue) + floatValue + Float(doubleValue)
let sumOfDouble = Double(intValue) + Double(floatValue) + doubleValue

//3

if Double(sumOfInt) < sumOfDouble {
    println("Double is more precision!")
    
} else if Double(sumOfInt) == sumOfDouble {
    println("Int is equal")
    
} else {
    println("Integer is greater!")
}






