// ADVANCED OPERATORS

// ~ ~ Bitwise Operators


// Bitwise NOT Operator (~)
//The bitwise NOT operator (~) inverts all bits in a number:

let initialBits: UInt8 = 0b00001111
let invertedBits = ~initialBits


// Bitwise AND Operator
// The bitwise AND operator (&) combines the bits of two numbers. It returns a new number whose bits are set to 1 only if the bits were equal to 1 in ``both`` input numbers:

let firstSixBits: UInt8 = 0b11111100
let lastSixBits: UInt8 = 0b00111111
let middleFourBits = firstSixBits & lastSixBits

// Bitwise OR Operator
// The bitwise OR operator (|) compares the bits of two numbers. The operator returns a new number whose bits are set to 1 if the bits are equal to 1 in ``either`` input number:

let someBits: UInt8 = 0b10110010
let moreBits: UInt8 = 0b01011110
let combinedBits = someBits | moreBits

// Bitwise XOR Operator
// The bitwise XOR operator, or “exclusive OR operator” (^), compares the bits of two numbers. The operator returns a new number whose bits are set to 1 where the input bits are different and are set to 0 where the input bits are the same:

let firstBits: UInt8 = 0b00010100
let otherBits: UInt8 = 0b00000101
let outputBits = firstBits ^ otherBits


// ~ Bitwise Left and Right Shift Operators =====

// `Shifting Behavior for Unsigned Integers`

var shiftBits: UInt8 = 4
shiftBits << 1
shiftBits << 2
shiftBits << 5
shiftBits << 6
shiftBits >> 2

let pink: UInt32 = 0xCC6699
let redComponent = (pink & 0xFF0000) >> 16
let greenComponent = (pink & 0x00FF00) >> 8
let blueComponent = pink & 0x0000FF

// `Shifting Behavior for Signed Integers`

// Signed integers use their first bit (known as the sign bit) to indicate whether the integer is positive or negative. A sign bit of 0 means positive, and a sign bit of 1 means negative.
//Negative numbers are stored by subtracting their absolute value from 2 to the power of n, where n is the number of value bits. An eight-bit number has seven value bits, so this means 2 to the power of 7, or 128. -4 = 128 - 4 = 124
//When you shift signed integers to the right, apply the same rules as for unsigned integers, but fill any empty bits on the left with the sign bit, rather than with a zero.

// ~ Overflow Operators =====
/*
Overflow addition (&+)
Overflow subtraction (&-)
Overflow multiplication (&*)
*/

// Value Overflow

var unsignedOverflow = UInt8.max
unsignedOverflow = unsignedOverflow &+ 1

var unsignedOverflow1 = UInt8.min
unsignedOverflow1 = unsignedOverflow &- 1

var signedOverflow = Int8.min
signedOverflow = signedOverflow &- 1

//For both signed and unsigned integers, overflow in the positive direction wraps around from the maximum valid integer value back to the minimum, and overflow in the negative direction wraps around from the minimum value to the maximum.