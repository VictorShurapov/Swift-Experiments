import Foundation
import UIKit

var a = [1, 2, 3]

a.insertContentsOf([5,6], at: 2)

//a.removeRange(0...1)

let c = a.filter( {$0 % 2 == 0} )
c

let b = a.map( {"\($0)"} )
b

let cc = a.reduce(0) { $0 + $1 }
cc

var ars = "abc"
var abs = "def"


var ss = "hello"
ss.insertContentsOf(" ,my friend!".characters, at: ss.endIndex)

let num = "56.25"
if let decimalRange = num.rangeOfString("."){
    let wholeNumberPart = num[num.startIndex..<decimalRange.startIndex]
}

a.description

var array = ["1", "2", "3"]

let stringRepresentation = array.joinWithSeparator("-")

let str = "Andrew, Ben, John, Paul, Peter, Laura"
let array1 = str.componentsSeparatedByString(", ")


let s = String(["f", "d"])

let aa = Array(arrayLiteral: "abc")

var asdf = a.map{ $0.description }.joinWithSeparator(" ")
asdf

ars.stringByReplacingOccurrencesOfString("c", withString: "dd")

// NSUserDefaults

let defaults = NSUserDefaults.standardUserDefaults()
let plist: AnyObject = 45

defaults.setDouble(45, forKey: "22")
defaults.synchronize()

let doubleX = defaults.doubleForKey("22")

let plist1 = defaults.objectForKey("1")


protocol Test1: Test2 {
    var abc: Int { get }
}

protocol Test2 {
    func testtt()
}

struct Pip: Test1 {
    var abc = 10
    func testtt() {
        <#code#>
    }
}
