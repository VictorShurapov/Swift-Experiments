class Human {
    var dad: Male?
    var mom: Female?
    var bros: [Male]?
    var sisters: [Female]?
    var pets: [Pet]?
    
}

class Male: Human {
    func move() {
        println("I moving the couch!")
    }
}

class Female: Human {
    func askAMan() {
        println("Please, move that couch!")
    }
}

class Pet {
    func voice() {
    }
}

class Cat: Pet {
    override func voice() {
        println("Meow!")
    }
}

class Dog: Pet {
    override func voice() {
        println("Woof!")
    }
    
}

func generate() -> (Male, [Human]) {
    
    
    let males = [Male(), Male(), Male(), Male(), Male()]
    let females = [Female(), Female(), Female(), Female(), Female(), Female()]
    
    var human = males[4]
    
    human.dad = males[0]
    human.mom = females[0]
    
    // uncles
    
    human.mom?.bros = [males[1], males[2]]
    
    // aunts
    
    human.mom?.sisters = [females[1]]
    human.dad?.sisters = [females[2], females[3], females[4]]
    
    // granddad
    
    human.dad?.dad = males[3]
    
    //grandmother
    
    human.mom?.mom = females[5]
    
    // pets
    
    human.dad?.pets = [Dog()]
    human.mom?.pets = [Cat(), Dog()]
    
    return (human, males as [Human] + females)
}


let (human, humans) = generate()

var count = (aunts: 0, uncles: 0, males: 0, females: 0, dogs: 0, cats: 0)

count.uncles += human.mom?.bros?.count ?? 0
count.aunts += human.mom?.sisters?.count ?? 0
count.aunts += human.dad?.sisters?.count ?? 0

for human in humans {
    if let human = human as? Male {
        count.males++
        human.move()
    } else if let human = human as? Female {
        count.females++
        human.askAMan()
    }
}
println()
for human in humans {
    if human.pets == nil {
        continue
    }
    for pet in human.pets! {
        switch pet {
        case is Dog: count.dogs++
        pet.voice()
        case is Cat: count.cats++
        pet.voice()
            
        default: break
        }
        
    }
}

println("\nOur network contains - aunts: \(count.aunts), uncle: \(count.uncles), males: \(count.males), females: \(count.females), dogs: \(count.dogs), cats: \(count.cats)")
