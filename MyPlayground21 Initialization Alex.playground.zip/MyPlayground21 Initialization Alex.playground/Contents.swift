import Foundation

class Human {
    var weight: Int
    var age: Int
    
    init(weight: Int, age: Int) {
        self.weight = weight
        self.age = age
    }
    
    convenience init(age: Int) {
        self.init(weight: 0, age: age)
    }
    
    convenience init(weight: Int) {
        self.init(weight: weight, age: 0)
    }
    
    convenience init() {
        self.init(weight: 0)
    }
    
    func test(){}
    deinit {
        println("Human deinitialized")
    }
}


enum Color: Int {
    case Black
    case White
    
    init?(_ value: Int) { // failable init
        switch value {
        case 0: self = Black
        case 1: self = White
            
        default: return nil
        }
    }
}

let a = Color(2)
let b = Color(0)
a?.rawValue
b?.rawValue

//let c = Color(rawValue: 0) identic init with `raw value`
//c?.rawValue



struct Size {
    var w = 0
    var h = 0
    
    init?(w: Int, h: Int) {
        self.w = w
        if h < 0 {
            return nil
        }
        self.h = h
    }
}

let cc = Size(w: 1, h: 1)
let bb = Size(w: 1, h: -1)



class Friend : Human {
    
    var name : String!
    
    let skin : Color = {
        let random = Int(arc4random_uniform(2))
        return Color(random)!
        }()
    
    init?(name: String) {
        self.name = name
        
        super.init(weight: 0, age: 0)
        if name.isEmpty {
            return nil
        }
    }
    
    required init() {
        self.name = "Hi"
        super.init(weight: 0, age: 0)
    }
    
    deinit {
        println("Friend deinitialized")
    }
    
}



let f = Friend(name: "a")
f?.name

class BestFriend: Friend {
    override init?(name: String) {
        super.init(name: name)
        self.name = "Piu"
    }
    
    required init() { // обязательно переопределить инит!!
        super.init()
    }
    deinit {
        println("BestFriend deinitialized")
    }
}

struct Test {
    var bestFriend : BestFriend? = BestFriend(name: "XC")
}

var test : Test? = Test()
test!.bestFriend = nil

var f5 = Friend(name: "")

// Deinitiliazers in Action

struct Bank {
    static var coinsInBank = 10_000
    static func vendCoins(var numberOfCoinsToVend: Int) -> Int {
        numberOfCoinsToVend = min(numberOfCoinsToVend, coinsInBank)
        coinsInBank -= numberOfCoinsToVend
        return numberOfCoinsToVend
    }
    static func receiveCoins(coins: Int) {
        coinsInBank += coins
    }
}

class Player {
    var coinsInPurse: Int
    init(coins: Int) {
        coinsInPurse = Bank.vendCoins(coins)
    }
    func winCoins(coins: Int) {
        coinsInPurse += Bank.vendCoins(coins)
    }
    deinit {
        Bank.receiveCoins(coinsInPurse)
    }
}

var playerOne: Player? = Player(coins: 100)
println("A new player has joined the game with \(playerOne!.coinsInPurse) coins")
println("There are now \(Bank.coinsInBank) coins left in the bank")

playerOne?.winCoins(2_000)
println("PlayerOne won 2000 coins & now has \(playerOne!.coinsInPurse) coins")
println("The bank now only has \(Bank.coinsInBank) coins left")

playerOne = nil
println("PlayerOne has left the game")
println("The bank now has \(Bank.coinsInBank) coins")