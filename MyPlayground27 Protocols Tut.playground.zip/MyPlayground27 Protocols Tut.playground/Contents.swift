// ~ ~ Protocols

// ~ Protocol syntax  =====

/*
protocol SomeProtocol {
    // protocol definition goes here
}

struct SomeStructure: FirstProtocol, AnotherProtocol {
    // structure definition goes here
}

class SomeClass: SomeSuperclass, FirstProtocol, AnotherProtocol {
    // class definition goes here
}*/

// ~ Property Requirements   === ==

protocol SomeProtocol {
    var mustBeSettable: Int { get set }
    var doesNotNeedToBeSettable: Int { get }
}

protocol AnotherProtocol {
    static var someTypeProperty: Int { get set }
}

protocol FullyNamed {
    var fullName: String { get }
}

struct Person: FullyNamed {
    var fullName: String
}

let john = Person(fullName: "John Appleseed")
john.fullName  // get

class Starship: FullyNamed {
    var prefix: String?
    var name: String
    init(name: String, prefix: String? = nil) {
        self.name = name
        self.prefix = prefix
    }
    var fullName: String {
        return (prefix != nil ? prefix! + " " : "") + name
    }
}

var ncc1701 = Starship(name: "Enterprise", prefix: "USS")
ncc1701.fullName

// ~ Method Requirements    === ==

protocol Some1Protocol {
    static func someTypeMethod()
}
protocol RandomNumberGenerator {
    func random() -> Double
}

class LinearCongruentialGenerator: RandomNumberGenerator {
    var lastRandom = 42.0
    let m = 139968.0
    let a = 3877.0
    let c = 29573.0
    func random() -> Double {
        lastRandom = ((lastRandom * a + c) % m)
        return lastRandom / m
    }
}

let generator = LinearCongruentialGenerator()
println("Here's a random number: \(generator.random())")

println("And another one: \(generator.random())")


// ~ Mutating Method Requirements   === ==

protocol Togglable {
    mutating func toggle()
}

enum OnOffSwitch: Int, Togglable {
    case Off = 0
    case On = 1
    mutating func toggle() {
        switch self {
        case Off:
            self = On
        case On:
            self = Off
        }
    }
}

var lightSwitch = OnOffSwitch.Off
lightSwitch.rawValue
lightSwitch.toggle()
lightSwitch.rawValue

// ~ Initializer Requirements  === ==

protocol Some2Protocol {
    init(someParameter: Int)
}

// Class Implementation of Protocol Initializer Requirements

class SomeClass: Some2Protocol {
    required init(someParameter: Int) {
        // initializer implementation goes here
    }
}

protocol Some3Protocol {
    init()
}

class SomeSuperClass {
    init() {
        // initializer implementation goes here
    }
}

class SomeSubClass: SomeSuperClass, Some3Protocol {
    // "required" from SomeProtocol conformance; "override from SomeSuperClass
    required override init() {
        // initializer implementation goes here
    }
}