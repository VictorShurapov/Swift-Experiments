// 1. Расширьте енум из урока и добавьте в него метод, помогающий установить соответствующий бит в переданную маску и метод, помогающий его прочитать. Эти методы должны принимать и возвращать маску, либо принимать адрес маски и менять его

enum CheckList : UInt8 {
    case Bread =    0b00000001
    case Chicken =  0b00000010
    case Apples =   0b00000100
    case Pears =    0b00001000
}

extension CheckList {
    typealias List = UInt8
    static func set(item: CheckList, inout inList list: List) {
        list |= item.rawValue
    }
    static func check(item: CheckList, inList list: List) -> Bool {
        return (list & item.rawValue) > 0
    }
}

var list: CheckList.List = 0b0000_0000

CheckList.set(.Apples, inList: &list)

CheckList.check(.Bread, inList: list)
CheckList.check(.Chicken, inList: list)
CheckList.check(.Apples, inList: list)
CheckList.check(.Pears, inList: list)

// 2. Создать цикл, который будет выводить 1 байтное число с одним установленным битом в такой последовательности, чтобы в консоли получилась вертикальная синусоида

extension UInt8 {
    func binary() -> String {
        var result = ""
        for i in 0..<8 {
            let mask = 1 << i
            let set = Int(self) & mask != 0
            result = (set ? "1" : "0") + result
        }
        return result
    }
}


var x: UInt8 = 0b1000_0000
println(x.binary())

for var i = 0, left = true; i < 21; i++ {
    
    if x >> 1 == 0 || x << 1 == 0 {
        left = !left
    }
    
    if left {
        x <<= 1
    } else {
        x >>= 1
    }
    
    println(x.binary())
}


// 3. Создайте 64х битное число, которое представляет клетки на шахматной доске. Установите биты так, что 0 - это белое поле, а 1 - черное. Младший бит это клетка а1 и каждый следующий байт начинается с клетки а (а2, а3, а4) и заканчивается клеткой h(h2, h3, h4). Выбирая клетки но индексу столбца и строки определите цвет клетки опираясь исключительно на значение соответствующего бита.

extension Int {
    func binary() -> String {
        var result = ""
        for i in 0..<64 {
            let mask = 1 << i
            let set = self & mask != 0
            result = (set ? "1" : "0") + result
        }
        return result
    }
}

var board = 0

for i in 0..<64 {
    if i % 2 == i / 8 % 2 {
        board |= 1 << i
    }
}

func color(x: Int, y: Int) -> String {
    let i = (y * 8) - 8 + (x - 1)
    let bit = board & 1 << i != 0
    return bit ? "black" : "white"
}

println()
println(board.binary())
color(1, 1) // a, 1
color(1, 8) // a, 8
color(8, 1) // h, 1
color(5, 5) // e, 5
